<?php
// google_auth.php - Google OAuth handler
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

// In production, integrate with Google OAuth2 API using CLIENT_ID: xwdukttlyhnjavkq
// For now, show a clear setup message
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Sign In – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>*{font-family:'DM Sans',sans-serif;}.font-display{font-family:'Playfair Display',serif;}</style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
    <div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-xl text-center">
        <div class="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
        </div>
        <h2 class="font-display text-xl font-bold text-gray-900 mb-2">Google OAuth Setup Required</h2>
        <p class="text-gray-500 text-sm mb-6">
            To enable Google Sign-In, configure your OAuth credentials in <code class="bg-gray-100 px-1 rounded">includes/config.php</code>:<br><br>
            <strong>Client ID:</strong> xwdukttlyhnjavkq<br>
            Add your Client Secret and configure the Google Cloud Console redirect URI.
        </p>
        <div class="bg-gray-50 rounded-xl p-4 text-left text-xs text-gray-500 mb-6 font-mono">
            // In config.php:<br>
            define('GOOGLE_CLIENT_SECRET', 'YOUR_SECRET');<br>
            // Redirect URI: <?=SITE_URL?>/pages/google_callback.php
        </div>
        <div class="flex gap-3">
            <a href="login.php" class="flex-1 bg-gray-900 text-white py-3 rounded-xl text-sm font-medium">Back to Login</a>
            <a href="register.php" class="flex-1 border-2 border-gray-200 text-gray-700 py-3 rounded-xl text-sm font-medium">Register</a>
        </div>
    </div>
</body>
</html>
