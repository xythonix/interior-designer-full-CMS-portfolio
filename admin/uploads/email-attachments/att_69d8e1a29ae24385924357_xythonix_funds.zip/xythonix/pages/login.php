<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if(empty($email)||empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if($user && password_verify($password, $user['password'])) {
            if($user['status'] === 'suspended') {
                $error = 'Your account has been suspended. Contact support.';
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];
                if($user['role'] === 'admin') {
                    header('Location: ../admin/dashboard.php'); exit;
                } else {
                    header('Location: dashboard.php'); exit;
                }
            }
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *{font-family:'DM Sans',sans-serif;}
        .font-display{font-family:'Playfair Display',serif;}
        :root{--gold:#C9A84C;--gold-light:#F0D080;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold),var(--gold-light));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),var(--gold-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
        .input-field{transition:all 0.3s;border:2px solid #e5e7eb;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 4px rgba(201,168,76,0.1);}
        .side-panel{background:linear-gradient(160deg,var(--navy) 0%,#142240 100%);}
        .stat-item{background:rgba(255,255,255,0.05);border:1px solid rgba(201,168,76,0.2);}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex">

<div class="hidden lg:flex lg:w-5/12 side-panel flex-col justify-between p-12">
    <a href="../index.php" class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center">
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
        </div>
        <span class="font-display text-xl font-bold text-white">Xythonix <span class="gold-text">Funds</span></span>
    </a>
    <div>
        <h2 class="font-display text-4xl font-bold text-white leading-tight mb-6">Welcome <span class="gold-text">Back</span></h2>
        <p class="text-white/50 mb-10">Your investments are working hard. Check in to see this month's compounding returns.</p>
        <div class="grid grid-cols-2 gap-4">
            <div class="stat-item rounded-2xl p-4">
                <div class="gold-text font-display text-2xl font-bold">3–5%</div>
                <div class="text-white/40 text-xs mt-1">Monthly Returns</div>
            </div>
            <div class="stat-item rounded-2xl p-4">
                <div class="gold-text font-display text-2xl font-bold">100%</div>
                <div class="text-white/40 text-xs mt-1">Compound Growth</div>
            </div>
            <div class="stat-item rounded-2xl p-4">
                <div class="gold-text font-display text-2xl font-bold">BEP2</div>
                <div class="text-white/40 text-xs mt-1">USDT Network</div>
            </div>
            <div class="stat-item rounded-2xl p-4">
                <div class="gold-text font-display text-2xl font-bold">24/7</div>
                <div class="text-white/40 text-xs mt-1">Support Available</div>
            </div>
        </div>
    </div>
    <p class="text-white/20 text-xs">© 2025 Xythonix Funds. Investment involves risk.</p>
</div>

<div class="flex-1 flex items-center justify-center p-6 lg:p-12">
    <div class="w-full max-w-md">
        <div class="lg:hidden flex items-center gap-2 mb-8">
            <a href="../index.php" class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg gold-gradient flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                </div>
                <span class="font-display font-bold" style="color:var(--navy)">Xythonix Funds</span>
            </a>
        </div>

        <h1 class="font-display text-3xl font-bold text-gray-900 mb-2">Sign In</h1>
        <p class="text-gray-500 mb-8">Don't have an account? <a href="register.php" class="font-medium" style="color:var(--gold-dark)">Create one free</a></p>

        <?php if($error): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <?=htmlspecialchars($error)?>
        </div>
        <?php endif; ?>

        <a href="google_auth.php" class="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl bg-white border-2 border-gray-200 hover:border-yellow-400 text-gray-700 font-medium mb-6 transition-all">
            <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
        </a>

        <div class="relative flex items-center mb-6">
            <div class="flex-1 border-t border-gray-200"></div>
            <span class="px-4 text-gray-400 text-sm">or sign in with email</span>
            <div class="flex-1 border-t border-gray-200"></div>
        </div>

        <form method="POST" class="space-y-5">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <input type="email" name="email" value="<?=sanitize($_POST['email']??'')?>" placeholder="john@example.com" class="input-field w-full px-4 py-3.5 rounded-xl bg-white text-gray-900" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">
                    Password
                    <a href="forgot_password.php" class="float-right font-normal text-xs" style="color:var(--gold-dark)">Forgot password?</a>
                </label>
                <div class="relative">
                    <input type="password" name="password" id="pw" placeholder="Your password" class="input-field w-full px-4 py-3.5 rounded-xl bg-white text-gray-900 pr-12" required>
                    <button type="button" onclick="togglePw()" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                        <svg id="eye-icon" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn-gold w-full py-4 rounded-xl text-white font-semibold text-base">
                Sign In to Dashboard
            </button>
        </form>
        
        <p class="text-center text-gray-400 text-xs mt-8">
            Default admin: admin@xythonixfunds.com / password
        </p>
    </div>
</div>

<script>
function togglePw(){
    const pw = document.getElementById('pw');
    pw.type = pw.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
