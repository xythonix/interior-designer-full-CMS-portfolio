<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }
$msg = ''; $err = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $email = sanitize($_POST['email']??'');
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM users WHERE email=?");
    $stmt->execute([$email]);
    if($stmt->fetch()){
        // In production: generate token, store in DB, send email
        $msg = "If that email exists, a reset link has been sent. (Email integration required in production.)";
    } else { $msg = "If that email exists, a reset link has been sent."; }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Forgot Password – Xythonix Funds</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>*{font-family:'DM Sans',sans-serif;}.font-display{font-family:'Playfair Display',serif;}
:root{--gold:#C9A84C;--gold-dark:#9A7A2E;}
.input-field{border:2px solid #e5e7eb;transition:all 0.3s;}
.input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 3px rgba(201,168,76,0.1);}
.btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
.btn-gold:hover{transform:translateY(-1px);}
</style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
<div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-sm border border-gray-100">
    <a href="login.php" class="flex items-center gap-2 text-gray-400 hover:text-gray-600 text-sm mb-6 transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg> Back to login
    </a>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-2">Reset Password</h1>
    <p class="text-gray-500 text-sm mb-6">Enter your email and we'll send a reset link.</p>
    <?php if($msg): ?><div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-4 text-sm"><?=$msg?></div><?php endif; ?>
    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
            <input type="email" name="email" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" placeholder="you@example.com" required>
        </div>
        <button type="submit" class="btn-gold w-full py-3.5 rounded-xl text-white font-semibold">Send Reset Link</button>
    </form>
</div>
</body></html>
