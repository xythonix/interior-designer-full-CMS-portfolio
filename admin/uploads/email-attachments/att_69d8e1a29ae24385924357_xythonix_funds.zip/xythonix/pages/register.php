<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $referral = sanitize($_POST['referral_code'] ?? '');
    
    if(empty($name)||empty($email)||empty($password)) {
        $error = 'All fields are required.';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif(strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $refCode = generateReferralCode();
            $referredBy = null;
            if($referral) {
                $rs = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
                $rs->execute([$referral]);
                $ref = $rs->fetch();
                if($ref) $referredBy = $ref['id'];
            }
            $stmt = $db->prepare("INSERT INTO users (name, email, password, referral_code, referred_by, status) VALUES (?,?,?,?,?,'active')");
            $stmt->execute([$name, $email, $hash, $refCode, $referredBy]);
            $newId = $db->lastInsertId();
            if($referredBy) {
                $db->prepare("INSERT INTO referrals (referrer_id, referred_id) VALUES (?,?)")->execute([$referredBy, $newId]);
            }
            $_SESSION['user_id'] = $newId;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_role'] = 'user';
            header('Location: dashboard.php'); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        :root{--gold:#C9A84C;--gold-light:#F0D080;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold),var(--gold-light));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),var(--gold-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{background:linear-gradient(135deg,var(--gold),var(--gold-light));transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
        .input-field{transition:all 0.3s;border:2px solid #e5e7eb;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 4px rgba(201,168,76,0.1);}
        .side-panel{background:linear-gradient(160deg,var(--navy) 0%,#142240 100%);}
        .google-btn{border:2px solid #e5e7eb;transition:all 0.3s;}
        .google-btn:hover{border-color:var(--gold);background:#fafaf8;}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex">

<!-- Left Panel -->
<div class="hidden lg:flex lg:w-5/12 side-panel flex-col justify-between p-12">
    <div>
        <a href="../index.php" class="flex items-center gap-3 mb-16">
            <div class="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
            </div>
            <span class="font-display text-xl font-bold text-white">Xythonix <span class="gold-text">Funds</span></span>
        </a>
        <h2 class="font-display text-4xl font-bold text-white leading-tight mb-4">Start Your<br><span class="gold-text">Investment Journey</span></h2>
        <p class="text-white/50 leading-relaxed">Join thousands of investors earning compounding monthly returns on their USDT deposits.</p>
    </div>
    <div class="space-y-4">
        <?php $perks = [['Compound monthly returns','Profits reinvested automatically'],['KYC-secured platform','Identity verified and protected'],['BEP2 USDT deposits','Fast and low-fee transactions']]; foreach($perks as $p): ?>
        <div class="flex items-start gap-3">
            <div class="w-6 h-6 rounded-full gold-gradient flex items-center justify-center flex-shrink-0 mt-0.5">
                <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
            </div>
            <div>
                <div class="text-white font-medium text-sm"><?=$p[0]?></div>
                <div class="text-white/40 text-xs"><?=$p[1]?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Right Panel -->
<div class="flex-1 flex items-center justify-center p-6 lg:p-12">
    <div class="w-full max-w-md">
        <div class="lg:hidden flex items-center gap-2 mb-8">
            <a href="../index.php" class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg gold-gradient flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                </div>
                <span class="font-display font-bold" style="color:var(--navy)">Xythonix Funds</span>
            </a>
        </div>

        <h1 class="font-display text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
        <p class="text-gray-500 mb-8">Already have an account? <a href="login.php" class="font-medium" style="color:var(--gold-dark)">Sign in</a></p>

        <?php if($error): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <?=htmlspecialchars($error)?>
        </div>
        <?php endif; ?>

        <!-- Google Sign In -->
        <a href="google_auth.php" class="google-btn w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl bg-white text-gray-700 font-medium mb-6">
            <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
        </a>

        <div class="relative flex items-center mb-6">
            <div class="flex-1 border-t border-gray-200"></div>
            <span class="px-4 text-gray-400 text-sm">or register with email</span>
            <div class="flex-1 border-t border-gray-200"></div>
        </div>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
                <input type="text" name="name" value="<?=sanitize($_POST['name']??'')?>" placeholder="John Doe" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <input type="email" name="email" value="<?=sanitize($_POST['email']??'')?>" placeholder="john@example.com" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                    <input type="password" name="password" placeholder="Min 8 chars" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Confirm</label>
                    <input type="password" name="confirm_password" placeholder="Repeat" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Referral Code <span class="text-gray-400 font-normal">(optional)</span></label>
                <input type="text" name="referral_code" value="<?=sanitize($_GET['ref']??'')?>" placeholder="Enter referral code" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900 uppercase">
            </div>
            <div class="flex items-start gap-2 pt-1">
                <input type="checkbox" id="terms" required class="mt-1 rounded">
                <label for="terms" class="text-sm text-gray-500">I agree to the <a href="#" class="underline" style="color:var(--gold-dark)">Terms of Service</a> and <a href="#" class="underline" style="color:var(--gold-dark)">Privacy Policy</a></label>
            </div>
            <button type="submit" class="btn-gold w-full py-4 rounded-xl text-white font-semibold text-base mt-2">
                Create My Account
            </button>
        </form>
    </div>
</div>
</body>
</html>
