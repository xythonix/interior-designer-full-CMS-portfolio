-- Xythonix Funds Database Schema
CREATE DATABASE IF NOT EXISTS xythonix_funds;
USE xythonix_funds;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255),
    google_id VARCHAR(255) DEFAULT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    wallet_address VARCHAR(255) DEFAULT NULL,
    referral_code VARCHAR(20) UNIQUE,
    referred_by INT DEFAULT NULL,
    role ENUM('user','admin') DEFAULT 'user',
    status ENUM('active','suspended','pending') DEFAULT 'pending',
    email_verified TINYINT(1) DEFAULT 0,
    kyc_status ENUM('none','pending','verified','rejected') DEFAULT 'none',
    kyc_doc_front VARCHAR(255) DEFAULT NULL,
    kyc_doc_back VARCHAR(255) DEFAULT NULL,
    kyc_selfie VARCHAR(255) DEFAULT NULL,
    kyc_doc_type VARCHAR(50) DEFAULT NULL,
    kyc_submitted_at DATETIME DEFAULT NULL,
    kyc_reviewed_at DATETIME DEFAULT NULL,
    kyc_rejection_reason TEXT DEFAULT NULL,
    invested_balance DECIMAL(18,2) DEFAULT 0.00,
    profit_balance DECIMAL(18,2) DEFAULT 0.00,
    total_withdrawn DECIMAL(18,2) DEFAULT 0.00,
    referral_bonus DECIMAL(18,2) DEFAULT 0.00,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Deposits Table
CREATE TABLE IF NOT EXISTS deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    txn_hash VARCHAR(255) DEFAULT NULL,
    wallet_from VARCHAR(255) DEFAULT NULL,
    status ENUM('pending','verified','rejected') DEFAULT 'pending',
    notes TEXT DEFAULT NULL,
    admin_id INT DEFAULT NULL,
    verified_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Withdrawals Table
CREATE TABLE IF NOT EXISTS withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    wallet_to VARCHAR(255) NOT NULL,
    withdrawal_type ENUM('profit','total') DEFAULT 'profit',
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    notes TEXT DEFAULT NULL,
    admin_id INT DEFAULT NULL,
    processed_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Monthly Profits Table
CREATE TABLE IF NOT EXISTS monthly_profits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    month_year VARCHAR(7) NOT NULL,
    profit_percent DECIMAL(5,2) NOT NULL,
    status ENUM('draft','applied') DEFAULT 'draft',
    total_distributed DECIMAL(18,2) DEFAULT 0.00,
    applied_by INT DEFAULT NULL,
    applied_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Profit Distributions Table
CREATE TABLE IF NOT EXISTS profit_distributions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    monthly_profit_id INT NOT NULL,
    user_id INT NOT NULL,
    balance_snapshot DECIMAL(18,2) NOT NULL,
    profit_percent DECIMAL(5,2) NOT NULL,
    profit_amount DECIMAL(18,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (monthly_profit_id) REFERENCES monthly_profits(id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Transactions Table (unified feed)
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('deposit','withdrawal','profit','referral_bonus') NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    reference_id INT DEFAULT NULL,
    status ENUM('pending','completed','failed') DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- System Settings Table
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT DEFAULT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Referrals Table
CREATE TABLE IF NOT EXISTS referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_id INT NOT NULL,
    bonus_amount DECIMAL(18,2) DEFAULT 0.00,
    bonus_paid TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id),
    FOREIGN KEY (referred_id) REFERENCES users(id)
);

-- Insert Default Settings
INSERT INTO settings (setting_key, setting_value) VALUES
('system_wallet', 'TXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
('min_deposit', '50'),
('min_withdrawal', '20'),
('referral_bonus_percent', '2'),
('site_name', 'Xythonix Funds'),
('site_email', 'support@xythonixfunds.com'),
('monthly_profit_percent', '3'),
('withdrawal_fee_percent', '1')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- Insert Default Admin
INSERT INTO users (name, email, password, role, status, email_verified, kyc_status, referral_code) VALUES
('Super Admin', 'admin@xythonixfunds.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 1, 'verified', 'ADMIN001')
ON DUPLICATE KEY UPDATE email = email;
-- Default admin password: password
