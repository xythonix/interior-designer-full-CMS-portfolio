<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xythonix Funds – Grow Your Wealth</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #C9A84C;
            --gold-light: #F0D080;
            --gold-dark: #9A7A2E;
            --navy: #0A1628;
            --navy-mid: #142240;
            --cream: #FAF7F0;
            --text-dark: #1A1A2E;
        }
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        
        .hero-bg {
            background: linear-gradient(135deg, #0A1628 0%, #142240 40%, #1a3060 100%);
        }
        .gold-gradient { background: linear-gradient(135deg, var(--gold-dark), var(--gold), var(--gold-light)); }
        .gold-text { background: linear-gradient(135deg, var(--gold-dark), var(--gold-light)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        
        .card-glass {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(201,168,76,0.2);
        }
        .btn-gold {
            background: linear-gradient(135deg, var(--gold-dark), var(--gold));
            color: white;
            transition: all 0.3s ease;
        }
        .btn-gold:hover { 
            background: linear-gradient(135deg, var(--gold), var(--gold-light));
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(201,168,76,0.4);
        }
        .stat-card {
            background: white;
            border-left: 4px solid var(--gold);
            transition: all 0.3s;
        }
        .stat-card:hover { transform: translateY(-4px); box-shadow: 0 20px 40px rgba(10,22,40,0.1); }

        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-15px)} }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        .float { animation: float 6s ease-in-out infinite; }
        
        .step-line::after {
            content: '';
            position: absolute;
            top: 50%;
            right: -50%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, var(--gold), transparent);
        }
        
        nav { transition: all 0.3s; }
        nav.scrolled { background: rgba(10,22,40,0.98); backdrop-filter: blur(20px); }
        
        .particle {
            position: absolute;
            width: 4px; height: 4px;
            background: var(--gold);
            border-radius: 50%;
            opacity: 0.4;
            animation: float linear infinite;
        }
    </style>
</head>
<body class="bg-white text-gray-800">

<!-- Navigation -->
<nav id="navbar" class="fixed top-0 w-full z-50 py-4 px-6 transition-all">
    <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
            </div>
            <span class="font-display text-xl font-bold text-white">Xythonix <span class="gold-text">Funds</span></span>
        </div>
        <div class="hidden md:flex items-center gap-8">
            <a href="#how" class="text-white/70 hover:text-white text-sm transition">How It Works</a>
            <a href="#features" class="text-white/70 hover:text-white text-sm transition">Features</a>
            <a href="#returns" class="text-white/70 hover:text-white text-sm transition">Returns</a>
        </div>
        <div class="flex items-center gap-3">
            <?php if(isLoggedIn()): ?>
            <a href="pages/dashboard.php" class="btn-gold text-sm px-5 py-2.5 rounded-lg font-medium flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                Dashboard
            </a>
            <?php else: ?>
            <a href="pages/login.php" class="text-white/80 hover:text-white text-sm px-4 py-2 rounded-lg transition border border-white/20 hover:border-white/40">Sign In</a>
            <a href="pages/register.php" class="btn-gold text-sm px-5 py-2.5 rounded-lg font-medium">Get Started</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Hero -->
<section class="hero-bg min-h-screen flex items-center relative overflow-hidden">
    <!-- Animated particles -->
    <div id="particles" class="absolute inset-0 pointer-events-none"></div>
    <!-- Decorative circles -->
    <div class="absolute top-20 right-20 w-96 h-96 rounded-full border border-yellow-400/10 float" style="animation-delay:0s"></div>
    <div class="absolute top-40 right-40 w-64 h-64 rounded-full border border-yellow-400/10 float" style="animation-delay:2s"></div>
    <div class="absolute bottom-20 left-10 w-48 h-48 rounded-full border border-yellow-400/10 float" style="animation-delay:4s"></div>

    <div class="max-w-7xl mx-auto px-6 py-32 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
        <div>
            <div class="inline-flex items-center gap-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full px-4 py-2 mb-6">
                <div class="w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></div>
                <span class="text-yellow-400 text-sm font-medium">Compounding Monthly Returns</span>
            </div>
            <h1 class="font-display text-5xl lg:text-7xl font-bold text-white leading-tight mb-6">
                Grow Wealth<br>
                <span class="gold-text">Exponentially</span>
            </h1>
            <p class="text-white/60 text-lg leading-relaxed mb-10 max-w-xl">
                Invest in USDT (BEP2) and earn compounding monthly returns. Your profits are calculated on your growing balance — so your money works harder every month.
            </p>
            <div class="flex flex-wrap gap-4 mb-12">
                <a href="pages/register.php" class="btn-gold px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2">
                    Start Investing
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </a>
                <a href="#how" class="text-white border border-white/20 px-8 py-4 rounded-xl font-medium text-lg hover:bg-white/10 transition">How It Works</a>
            </div>
            <!-- Live Stats -->
            <div class="grid grid-cols-3 gap-4">
                <div class="card-glass rounded-2xl p-4 text-center">
                    <div class="font-display text-2xl font-bold gold-text">$2.4M+</div>
                    <div class="text-white/50 text-xs mt-1">Total Invested</div>
                </div>
                <div class="card-glass rounded-2xl p-4 text-center">
                    <div class="font-display text-2xl font-bold gold-text">3-5%</div>
                    <div class="text-white/50 text-xs mt-1">Monthly Returns</div>
                </div>
                <div class="card-glass rounded-2xl p-4 text-center">
                    <div class="font-display text-2xl font-bold gold-text">1,200+</div>
                    <div class="text-white/50 text-xs mt-1">Active Investors</div>
                </div>
            </div>
        </div>

        <!-- Floating Dashboard Preview -->
        <div class="hidden lg:block">
            <div class="card-glass rounded-3xl p-6 float shadow-2xl">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-white/60 text-sm">Portfolio Overview</span>
                    <span class="bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-full">Live</span>
                </div>
                <div class="text-white font-display text-4xl font-bold mb-1">$12,485.30</div>
                <div class="text-green-400 text-sm mb-6 flex items-center gap-1">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                    +$374.56 this month (3%)
                </div>
                <!-- Mini chart bars -->
                <div class="flex items-end gap-2 h-20 mb-4">
                    <?php $heights = [40,55,45,70,60,85,75,90,80,100,88,95]; foreach($heights as $h): ?>
                    <div class="flex-1 rounded-t-sm gold-gradient opacity-70" style="height:<?=$h?>%"></div>
                    <?php endforeach; ?>
                </div>
                <div class="flex justify-between text-white/30 text-xs">
                    <span>Jan</span><span>Apr</span><span>Jul</span><span>Oct</span><span>Dec</span>
                </div>
                <div class="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 gap-4">
                    <div>
                        <div class="text-white/40 text-xs">Invested</div>
                        <div class="text-white font-semibold">$10,000.00</div>
                    </div>
                    <div>
                        <div class="text-white/40 text-xs">Total Profit</div>
                        <div class="text-green-400 font-semibold">+$2,485.30</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works -->
<section id="how" class="py-24 bg-gray-50">
    <div class="max-w-7xl mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="font-display text-4xl font-bold text-gray-900 mb-4">How <span style="color:var(--gold-dark)">Xythonix</span> Works</h2>
            <p class="text-gray-500 text-lg max-w-2xl mx-auto">Four simple steps to start earning compounding monthly returns on your crypto investments.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <?php
            $steps = [
                ['01', 'Create Account', 'Sign up with email or Google. Verify your identity with KYC documents.', 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z'],
                ['02', 'Deposit USDT', 'Send BEP2 USDT to our secure wallet. Admin verifies your deposit.', 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z'],
                ['03', 'Earn Monthly', 'Profits calculated on your growing balance. Compound interest every month.', 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'],
                ['04', 'Withdraw Anytime', 'Request withdrawal from profit or total balance. Admin processes in BEP2 USDT.', 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
            ];
            foreach($steps as $i => $step):
            ?>
            <div class="text-center group">
                <div class="relative inline-flex mb-6">
                    <div class="w-20 h-20 rounded-2xl gold-gradient flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        <svg class="w-9 h-9 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="<?=$step[3]?>"/></svg>
                    </div>
                    <div class="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-navy-mid flex items-center justify-center text-xs font-bold" style="background:var(--navy)">
                        <span class="gold-text"><?=$step[0]?></span>
                    </div>
                </div>
                <h3 class="font-display text-xl font-bold text-gray-900 mb-2"><?=$step[1]?></h3>
                <p class="text-gray-500 text-sm leading-relaxed"><?=$step[2]?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Compounding Returns Section -->
<section id="returns" class="py-24" style="background:var(--navy)">
    <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
                <h2 class="font-display text-4xl font-bold text-white mb-4">The Power of <span class="gold-text">Compounding</span></h2>
                <p class="text-white/60 text-lg mb-8">Your profits are always calculated on your current balance — not your initial investment. This means every month, you earn more.</p>
                <div class="space-y-4">
                    <?php
                    $balance = 1000;
                    $months = ['Month 1', 'Month 2', 'Month 3', 'Month 6', 'Month 12'];
                    $monthNums = [1, 2, 3, 6, 12];
                    foreach($monthNums as $idx => $m):
                        $bal = 1000 * pow(1.03, $m);
                        $profit = $bal - 1000;
                        $width = min(100, ($bal/1400)*100);
                    ?>
                    <div class="flex items-center gap-4">
                        <div class="text-white/50 text-sm w-20 flex-shrink-0"><?=$months[$idx]?></div>
                        <div class="flex-1 bg-white/5 rounded-full h-8 relative overflow-hidden">
                            <div class="gold-gradient h-full rounded-full flex items-center justify-end pr-3" style="width:<?=$width?>%">
                                <span class="text-white text-xs font-medium"><?=formatCurrency($bal)?></span>
                            </div>
                        </div>
                        <div class="text-green-400 text-sm w-20 text-right">+<?=formatCurrency($profit)?></div>
                    </div>
                    <?php endforeach; function formatCurrency($a){return '$'.number_format($a,2);} ?>
                </div>
                <p class="text-white/30 text-xs mt-4">* Example based on $1,000 initial investment at 3% monthly compound interest.</p>
            </div>
            <div class="card-glass rounded-3xl p-8">
                <h3 class="font-display text-xl font-bold text-white mb-6">Returns Calculator</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-white/60 text-sm block mb-2">Initial Investment (USDT)</label>
                        <input type="number" id="calc_amount" value="1000" class="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-yellow-400 transition">
                    </div>
                    <div>
                        <label class="text-white/60 text-sm block mb-2">Monthly Return (%)</label>
                        <input type="number" id="calc_rate" value="3" step="0.1" class="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-yellow-400 transition">
                    </div>
                    <div>
                        <label class="text-white/60 text-sm block mb-2">Duration (months)</label>
                        <input type="number" id="calc_months" value="12" class="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-yellow-400 transition">
                    </div>
                    <div class="bg-yellow-400/10 border border-yellow-400/30 rounded-xl p-4">
                        <div class="text-white/50 text-sm mb-1">Estimated Return</div>
                        <div id="calc_result" class="font-display text-3xl font-bold gold-text">$0.00</div>
                        <div id="calc_profit" class="text-green-400 text-sm mt-1"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section id="features" class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="font-display text-4xl font-bold text-gray-900 mb-4">Platform <span style="color:var(--gold-dark)">Features</span></h2>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php
            $features = [
                ['KYC Verified', 'Full identity verification ensures a secure, compliant investment environment.', 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z'],
                ['BEP2 USDT', 'Deposit and withdraw in BEP2 USDT. Fast, low-fee transactions on Binance Chain.', 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z'],
                ['Real-Time Dashboard', 'Track your invested balance, profits, and withdrawal history all in one place.', 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'],
                ['Compound Growth', 'Monthly profits calculated on your growing balance — true compound returns.', 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6'],
                ['Referral Rewards', 'Earn bonus rewards by referring new investors to the platform.', 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z'],
                ['Profit History', 'Full monthly profit history with charts — see exactly how your money has grown.', 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'],
            ];
            foreach($features as $f):
            ?>
            <div class="stat-card rounded-2xl p-6">
                <div class="w-12 h-12 rounded-xl gold-gradient flex items-center justify-center mb-4">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$f[2]?>"/></svg>
                </div>
                <h3 class="font-semibold text-gray-900 text-lg mb-2"><?=$f[0]?></h3>
                <p class="text-gray-500 text-sm leading-relaxed"><?=$f[1]?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-24" style="background:linear-gradient(135deg,var(--navy),var(--navy-mid))">
    <div class="max-w-4xl mx-auto px-6 text-center">
        <h2 class="font-display text-5xl font-bold text-white mb-6">Ready to Start <span class="gold-text">Growing</span>?</h2>
        <p class="text-white/60 text-xl mb-10">Join thousands of investors already earning compounding monthly returns with Xythonix Funds.</p>
        <?php if(isLoggedIn()): ?>
        <a href="pages/dashboard.php" class="btn-gold inline-flex items-center gap-3 px-10 py-5 rounded-2xl font-semibold text-xl">
            Go to Dashboard
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
        </a>
        <?php else: ?>
        <a href="pages/register.php" class="btn-gold inline-flex items-center gap-3 px-10 py-5 rounded-2xl font-semibold text-xl">
            Create Free Account
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
        </a>
        <?php endif; ?>
    </div>
</section>

<!-- Footer -->
<footer style="background:var(--navy)" class="py-12 px-6">
    <div class="max-w-7xl mx-auto">
        <div class="flex flex-col md:flex-row items-center justify-between gap-6">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg gold-gradient flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                </div>
                <span class="font-display text-white font-bold">Xythonix Funds</span>
            </div>
            <p class="text-white/30 text-sm">© 2025 Xythonix Funds. All rights reserved. Investments involve risk.</p>
            <div class="flex gap-6">
                <?php if(isLoggedIn()): ?>
                <a href="pages/dashboard.php" class="text-white/40 hover:text-white text-sm transition flex items-center gap-1.5">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    Dashboard
                </a>
                <a href="pages/logout.php" class="text-white/40 hover:text-white text-sm transition">Sign Out</a>
                <?php else: ?>
                <a href="pages/login.php" class="text-white/40 hover:text-white text-sm transition">Sign In</a>
                <a href="pages/register.php" class="text-white/40 hover:text-white text-sm transition">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</footer>

<script>
// Navbar scroll
window.addEventListener('scroll', () => {
    document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
});

// Particle system
const pc = document.getElementById('particles');
for(let i=0;i<20;i++){
    const p=document.createElement('div');
    p.className='particle';
    p.style.cssText=`left:${Math.random()*100}%;top:${Math.random()*100}%;animation-duration:${4+Math.random()*8}s;animation-delay:${Math.random()*5}s;opacity:${0.1+Math.random()*0.3}`;
    pc.appendChild(p);
}

// Calculator
function calcReturns(){
    const amt=parseFloat(document.getElementById('calc_amount').value)||0;
    const rate=parseFloat(document.getElementById('calc_rate').value)||0;
    const months=parseInt(document.getElementById('calc_months').value)||0;
    const final=amt*Math.pow(1+rate/100,months);
    const profit=final-amt;
    document.getElementById('calc_result').textContent='$'+final.toFixed(2);
    document.getElementById('calc_profit').textContent='+$'+profit.toFixed(2)+' profit earned';
}
['calc_amount','calc_rate','calc_months'].forEach(id=>document.getElementById(id).addEventListener('input',calcReturns));
calcReturns();
</script>
</body>
</html>
