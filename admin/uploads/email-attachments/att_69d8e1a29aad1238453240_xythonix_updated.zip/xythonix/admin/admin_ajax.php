<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$db = getDB();
$adminId = $_SESSION['user_id'];

switch($action) {

    case 'process_deposit':
        $depositId = (int)($_POST['deposit_id'] ?? 0);
        $decision  = $_POST['decision'] ?? '';
        $reason    = sanitize($_POST['reason'] ?? '');

        $dep = $db->prepare("SELECT * FROM deposits WHERE id=?");
        $dep->execute([$depositId]);
        $deposit = $dep->fetch();
        if(!$deposit) jsonResponse(['success'=>false,'error'=>'Deposit not found.']);
        if($deposit['status'] !== 'pending') jsonResponse(['success'=>false,'error'=>'Deposit already processed.']);

        if($decision === 'verify') {
            $db->beginTransaction();
            try {
                // Mark deposit verified
                $db->prepare("UPDATE deposits SET status='verified', admin_id=?, verified_at=NOW() WHERE id=?")->execute([$adminId, $depositId]);
                // Add to user invested balance
                $db->prepare("UPDATE users SET invested_balance = invested_balance + ? WHERE id=?")->execute([$deposit['amount'], $deposit['user_id']]);
                // Update transaction status
                $db->prepare("UPDATE transactions SET status='completed' WHERE reference_id=? AND type='deposit'")->execute([$depositId]);

                // Check referral bonus on first deposit
                $depCount = $db->prepare("SELECT COUNT(*) FROM deposits WHERE user_id=? AND status='verified'");
                $depCount->execute([$deposit['user_id']]);
                if($depCount->fetchColumn() == 1) {
                    // First verified deposit — check if user was referred
                    $refStmt = $db->prepare("SELECT r.*, u.invested_balance FROM referrals r JOIN users u ON r.referrer_id=u.id WHERE r.referred_id=? AND r.bonus_paid=0");
                    $refStmt->execute([$deposit['user_id']]);
                    $ref = $refStmt->fetch();
                    if($ref) {
                        $bonusRate = (float)getSetting('referral_bonus_percent');
                        $bonusAmt  = $deposit['amount'] * $bonusRate / 100;
                        if($bonusAmt > 0) {
                            $db->prepare("UPDATE users SET referral_bonus = referral_bonus + ? WHERE id=?")->execute([$bonusAmt, $ref['referrer_id']]);
                            $db->prepare("UPDATE referrals SET bonus_amount=?, bonus_paid=1 WHERE id=?")->execute([$bonusAmt, $ref['id']]);
                            logTransaction($ref['referrer_id'], 'referral_bonus', $bonusAmt, 'Referral bonus from deposit verification');
                        }
                    }
                }
                $db->commit();
                jsonResponse(['success'=>true,'message'=>'Deposit verified and balance updated.']);
            } catch(Exception $e) {
                $db->rollBack();
                jsonResponse(['success'=>false,'error'=>'Transaction failed: '.$e->getMessage()]);
            }
        } elseif($decision === 'reject') {
            $db->prepare("UPDATE deposits SET status='rejected', admin_id=?, notes=? WHERE id=?")->execute([$adminId, $reason, $depositId]);
            $db->prepare("UPDATE transactions SET status='failed' WHERE reference_id=? AND type='deposit'")->execute([$depositId]);
            jsonResponse(['success'=>true,'message'=>'Deposit rejected.']);
        } else {
            jsonResponse(['success'=>false,'error'=>'Invalid decision.']);
        }
        break;

    case 'process_withdrawal':
        $wdId     = (int)($_POST['withdrawal_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';

        $wdStmt = $db->prepare("SELECT * FROM withdrawals WHERE id=?");
        $wdStmt->execute([$wdId]);
        $wd = $wdStmt->fetch();
        if(!$wd) jsonResponse(['success'=>false,'error'=>'Withdrawal not found.']);
        if($wd['status'] !== 'pending') jsonResponse(['success'=>false,'error'=>'Already processed.']);

        if($decision === 'approve') {
            $db->beginTransaction();
            try {
                $user = $db->prepare("SELECT * FROM users WHERE id=?");
                $user->execute([$wd['user_id']]);
                $user = $user->fetch();

                // Deduct from appropriate balance
                if($wd['withdrawal_type'] === 'profit') {
                    if($user['profit_balance'] < $wd['amount']) {
                        $db->rollBack();
                        jsonResponse(['success'=>false,'error'=>'Insufficient profit balance.']);
                    }
                    $db->prepare("UPDATE users SET profit_balance = profit_balance - ?, total_withdrawn = total_withdrawn + ? WHERE id=?")->execute([$wd['amount'], $wd['amount'], $wd['user_id']]);
                } else {
                    $totalBal = $user['invested_balance'] + $user['profit_balance'];
                    if($totalBal < $wd['amount']) {
                        $db->rollBack();
                        jsonResponse(['success'=>false,'error'=>'Insufficient balance.']);
                    }
                    // Deduct from profit first, then invested
                    $fromProfit = min($user['profit_balance'], $wd['amount']);
                    $fromInvest = $wd['amount'] - $fromProfit;
                    $db->prepare("UPDATE users SET profit_balance = profit_balance - ?, invested_balance = invested_balance - ?, total_withdrawn = total_withdrawn + ? WHERE id=?")->execute([$fromProfit, $fromInvest, $wd['amount'], $wd['user_id']]);
                }

                $db->prepare("UPDATE withdrawals SET status='approved', admin_id=?, processed_at=NOW() WHERE id=?")->execute([$adminId, $wdId]);
                $db->prepare("UPDATE transactions SET status='completed' WHERE reference_id=? AND type='withdrawal'")->execute([$wdId]);
                $db->commit();
                jsonResponse(['success'=>true,'message'=>'Withdrawal approved and balance deducted.']);
            } catch(Exception $e) {
                $db->rollBack();
                jsonResponse(['success'=>false,'error'=>$e->getMessage()]);
            }
        } elseif($decision === 'reject') {
            $db->prepare("UPDATE withdrawals SET status='rejected', admin_id=?, processed_at=NOW() WHERE id=?")->execute([$adminId, $wdId]);
            $db->prepare("UPDATE transactions SET status='failed' WHERE reference_id=? AND type='withdrawal'")->execute([$wdId]);
            jsonResponse(['success'=>true,'message'=>'Withdrawal rejected.']);
        }
        break;

    case 'distribute_profit':
        $currentMonth = date('Y-m');
        $profitRate   = (float)getSetting('monthly_profit_percent');

        // Check already applied
        $check = $db->prepare("SELECT id FROM monthly_profits WHERE month_year=? AND status='applied'");
        $check->execute([$currentMonth]);
        if($check->fetch()) jsonResponse(['success'=>false,'error'=>'Profit already distributed for '.$currentMonth]);

        // Get all eligible users (active, invested balance > 0)
        $eligible = $db->query("SELECT id, invested_balance, profit_balance, (invested_balance+profit_balance) as current_balance FROM users WHERE role='user' AND status='active' AND invested_balance > 0")->fetchAll();
        if(count($eligible) === 0) jsonResponse(['success'=>false,'error'=>'No eligible users with invested balance.']);

        $db->beginTransaction();
        try {
            // Insert monthly profit record
            $db->prepare("INSERT INTO monthly_profits (month_year, profit_percent, status, applied_by, applied_at) VALUES (?,?,'applied',?,NOW())")->execute([$currentMonth, $profitRate, $adminId]);
            $monthlyProfitId = $db->lastInsertId();

            $totalDistributed = 0;
            foreach($eligible as $u) {
                // COMPOUNDING: profit calculated on invested_balance + existing profit_balance
                $currentBalance = $u['invested_balance'] + $u['profit_balance'];
                $profitAmount   = $currentBalance * $profitRate / 100;
                $profitAmount   = round($profitAmount, 2);

                if($profitAmount <= 0) continue;

                // Add profit to user's profit_balance
                $db->prepare("UPDATE users SET profit_balance = profit_balance + ? WHERE id=?")->execute([$profitAmount, $u['id']]);

                // Record distribution
                $db->prepare("INSERT INTO profit_distributions (monthly_profit_id, user_id, balance_snapshot, profit_percent, profit_amount) VALUES (?,?,?,?,?)")->execute([$monthlyProfitId, $u['id'], $currentBalance, $profitRate, $profitAmount]);

                // Log transaction
                logTransaction($u['id'], 'profit', $profitAmount, "Monthly profit {$profitRate}% for {$currentMonth}", $monthlyProfitId);

                $totalDistributed += $profitAmount;
            }

            // Update total distributed
            $db->prepare("UPDATE monthly_profits SET total_distributed=? WHERE id=?")->execute([$totalDistributed, $monthlyProfitId]);

            $db->commit();
            jsonResponse(['success'=>true,'message'=>"Profit distributed to ".count($eligible)." users. Total: \$".number_format($totalDistributed,2)]);
        } catch(Exception $e) {
            $db->rollBack();
            jsonResponse(['success'=>false,'error'=>'Distribution failed: '.$e->getMessage()]);
        }
        break;

    case 'update_profit_rate':
        $rate = (float)($_POST['rate'] ?? 0);
        if($rate < 0 || $rate > 100) jsonResponse(['success'=>false,'error'=>'Invalid rate.']);
        $db->prepare("UPDATE settings SET setting_value=? WHERE setting_key='monthly_profit_percent'")->execute([$rate]);
        jsonResponse(['success'=>true]);
        break;

    case 'process_kyc':
        $userId   = (int)($_POST['user_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        $reason   = sanitize($_POST['reason'] ?? '');

        if($decision === 'verify') {
            $db->prepare("UPDATE users SET kyc_status='verified', kyc_reviewed_at=NOW(), status='active' WHERE id=?")->execute([$userId]);
            jsonResponse(['success'=>true,'message'=>'KYC verified successfully.']);
        } elseif($decision === 'reject') {
            $db->prepare("UPDATE users SET kyc_status='rejected', kyc_reviewed_at=NOW(), kyc_rejection_reason=? WHERE id=?")->execute([$reason, $userId]);
            jsonResponse(['success'=>true,'message'=>'KYC rejected.']);
        }
        break;

    case 'update_user':
        $userId   = (int)($_POST['user_id'] ?? 0);
        $name     = sanitize($_POST['name'] ?? '');
        $email    = sanitize($_POST['email'] ?? '');
        $invested = (float)($_POST['invested_balance'] ?? 0);
        $profit   = (float)($_POST['profit_balance'] ?? 0);
        $kyc      = $_POST['kyc_status'] ?? 'none';
        $status   = $_POST['status'] ?? 'active';

        if($userId <= 0 || empty($name)) jsonResponse(['success'=>false,'error'=>'Invalid data.']);

        $db->prepare("UPDATE users SET name=?,email=?,invested_balance=?,profit_balance=?,kyc_status=?,status=? WHERE id=? AND role='user'")->execute([$name,$email,$invested,$profit,$kyc,$status,$userId]);
        jsonResponse(['success'=>true]);
        break;

    case 'toggle_user_status':
        $userId = (int)($_POST['user_id'] ?? 0);
        $status = $_POST['status'] === 'active' ? 'active' : 'suspended';
        $db->prepare("UPDATE users SET status=? WHERE id=? AND role='user'")->execute([$status, $userId]);
        jsonResponse(['success'=>true]);
        break;

    case 'update_settings':
        $allowedKeys = ['system_wallet','min_deposit','min_withdrawal','monthly_profit_percent','referral_bonus_percent','withdrawal_fee_percent','site_name','site_email'];
        $updated = 0;
        foreach($allowedKeys as $key) {
            if(isset($_POST[$key])) {
                $db->prepare("UPDATE settings SET setting_value=? WHERE setting_key=?")->execute([sanitize($_POST[$key]), $key]);
                $updated++;
            }
        }
        jsonResponse(['success'=>true,'updated'=>$updated]);
        break;

    default:
        jsonResponse(['success'=>false,'error'=>'Unknown action.']);
}
?>
