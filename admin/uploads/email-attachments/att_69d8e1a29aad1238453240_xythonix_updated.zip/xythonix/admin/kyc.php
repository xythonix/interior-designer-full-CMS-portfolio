<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'KYC Reviews';
$db = getDB();

$filter = $_GET['status'] ?? 'pending';
$where  = $filter !== 'all' ? "WHERE kyc_status='$filter'" : "WHERE kyc_status IN ('pending','verified','rejected')";
$users  = $db->query("SELECT * FROM users $where AND role='user' ORDER BY kyc_submitted_at DESC")->fetchAll();

include 'header.php';
?>

<div class="flex gap-2 mb-6">
    <?php foreach(['pending'=>'Pending','verified'=>'Verified','rejected'=>'Rejected','all'=>'All'] as $k=>$v):
        $active=$filter===$k;
    ?>
    <a href="?status=<?=$k?>" class="px-4 py-2 rounded-xl text-sm font-medium transition <?=$active?'text-white':'bg-white text-gray-500 border border-gray-200 hover:border-yellow-400'?>" <?=$active?'style="background:var(--gold)"':''?>><?=$v?></a>
    <?php endforeach; ?>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
<?php if(count($users)===0): ?>
<div class="col-span-3 text-center py-16 text-gray-400 bg-white rounded-2xl stat-card">
    <p>No KYC submissions found</p>
</div>
<?php else: foreach($users as $u):
    $kycColors=['pending'=>'badge-yellow','verified'=>'badge-green','rejected'=>'badge-red'];
?>
<div class="bg-white rounded-2xl p-5 stat-card">
    <div class="flex items-center justify-between mb-4">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full gold-gradient flex items-center justify-center text-white text-sm font-bold"><?=strtoupper(substr($u['name'],0,2))?></div>
            <div>
                <div class="font-medium text-gray-900"><?=htmlspecialchars($u['name'])?></div>
                <div class="text-gray-400 text-xs"><?=htmlspecialchars($u['email'])?></div>
            </div>
        </div>
        <span class="<?=$kycColors[$u['kyc_status']]?> px-2 py-0.5 rounded-full text-xs"><?=ucfirst($u['kyc_status'])?></span>
    </div>

    <div class="space-y-2 mb-4">
        <div class="text-xs text-gray-400">Document Type: <span class="text-gray-700 font-medium"><?=ucfirst(str_replace('_',' ',$u['kyc_doc_type']??'N/A'))?></span></div>
        <div class="text-xs text-gray-400">Submitted: <span class="text-gray-700"><?=$u['kyc_submitted_at']?date('M j, Y H:i',strtotime($u['kyc_submitted_at'])):'—'?></span></div>
    </div>

    <!-- Document Previews -->
    <div class="grid grid-cols-3 gap-2 mb-4">
        <?php
        $docs = [
            ['Front', $u['kyc_doc_front']],
            ['Back',  $u['kyc_doc_back']],
            ['Selfie',$u['kyc_selfie']],
        ];
        foreach($docs as $doc): ?>
        <div class="text-center">
            <div class="text-xs text-gray-400 mb-1"><?=$doc[0]?></div>
            <?php if($doc[1] && file_exists(UPLOAD_PATH.$doc[1])): ?>
            <a href="<?=UPLOAD_URL.$doc[1]?>" target="_blank">
                <img src="<?=UPLOAD_URL.$doc[1]?>" class="w-full h-16 object-cover rounded-lg border-2 border-gray-100 hover:border-yellow-400 transition cursor-pointer">
            </a>
            <?php else: ?>
            <div class="w-full h-16 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200 flex items-center justify-center">
                <span class="text-gray-300 text-xs">No file</span>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if($u['kyc_status']==='pending'): ?>
    <div class="space-y-2">
        <div class="flex gap-2">
            <button onclick="kycAction(<?=$u['id']?>,'verify')" class="flex-1 bg-green-500 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-green-600 transition">✓ Verify</button>
            <button onclick="openKycReject(<?=$u['id']?>)" class="flex-1 bg-red-100 text-red-600 py-2.5 rounded-xl text-sm font-medium hover:bg-red-200 transition">✗ Reject</button>
        </div>
    </div>
    <?php elseif($u['kyc_status']==='rejected' && $u['kyc_rejection_reason']): ?>
    <div class="bg-red-50 rounded-lg p-2 text-xs text-red-600">
        <strong>Reason:</strong> <?=htmlspecialchars($u['kyc_rejection_reason'])?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; endif; ?>
</div>

<!-- Reject KYC Modal -->
<div id="kycRejectModal" class="modal-overlay">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md mx-4 shadow-2xl">
        <h3 class="font-display font-bold text-gray-900 mb-4">Reject KYC</h3>
        <input type="hidden" id="kyc_reject_id">
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Rejection Reason</label>
            <textarea id="kyc_reject_reason" rows="3" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 text-sm" placeholder="e.g. Document is blurry, face not visible..."></textarea>
        </div>
        <div class="flex gap-3">
            <button onclick="submitKycReject()" class="flex-1 bg-red-500 text-white py-3 rounded-xl font-medium hover:bg-red-600 transition">Reject KYC</button>
            <button onclick="closeModal('kycRejectModal')" class="flex-1 bg-gray-100 py-3 rounded-xl font-medium text-gray-700">Cancel</button>
        </div>
    </div>
</div>

<script>
function kycAction(id, action){
    if(!confirm('Are you sure you want to '+action+' this KYC?')) return;
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'process_kyc', user_id:id, decision:action},
        dataType:'json',
        success:r=>{ if(r.success){showToast(r.message,'success');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
}
function openKycReject(id){ $('#kyc_reject_id').val(id); openModal('kycRejectModal'); }
function submitKycReject(){
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'process_kyc', user_id:$('#kyc_reject_id').val(), decision:'reject', reason:$('#kyc_reject_reason').val()},
        dataType:'json',
        success:r=>{ if(r.success){showToast('KYC Rejected','success');closeModal('kycRejectModal');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
}
</script>

<?php include 'footer.php'; ?>
