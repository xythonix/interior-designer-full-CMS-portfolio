<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'Admin Dashboard';
$db = getDB();

// Key stats
$totalUsers    = $db->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$activeUsers   = $db->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='active'")->fetchColumn();
$kycPending    = $db->query("SELECT COUNT(*) FROM users WHERE kyc_status='pending'")->fetchColumn();
$totalDeposited= $db->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='verified'")->fetchColumn();
$totalWithdrawn= $db->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='approved'")->fetchColumn();
$pendingDep    = $db->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn();
$pendingWd     = $db->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
$systemBalance = $db->query("SELECT COALESCE(SUM(invested_balance+profit_balance),0) FROM users WHERE role='user'")->fetchColumn();
$monthlyRate   = getSetting('monthly_profit_percent');

// Monthly deposit chart (last 6 months)
$depChart = $db->query("SELECT DATE_FORMAT(created_at,'%Y-%m') as m, SUM(amount) as total FROM deposits WHERE status='verified' AND created_at >= DATE_SUB(NOW(),INTERVAL 6 MONTH) GROUP BY m ORDER BY m")->fetchAll();

// Recent deposits
$recentDep = $db->query("SELECT d.*,u.name,u.email FROM deposits d JOIN users u ON d.user_id=u.id ORDER BY d.created_at DESC LIMIT 6")->fetchAll();

// Recent withdrawals
$recentWd = $db->query("SELECT w.*,u.name FROM withdrawals w JOIN users u ON w.user_id=u.id ORDER BY w.created_at DESC LIMIT 6")->fetchAll();

include 'header.php';
?>

<!-- Stats Grid -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
<?php
$cards = [
    ['Total Users',    $totalUsers,                  'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z', '#2563eb','bg-blue-50'],
    ['Total Deposited','$'.number_format($totalDeposited,2),'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z','#16a34a','bg-green-50'],
    ['System Balance', '$'.number_format($systemBalance,2),'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z','var(--gold-dark)','bg-yellow-50'],
    ['Total Withdrawn','$'.number_format($totalWithdrawn,2),'M15 12H9m6 0l-3-3m3 3l-3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z','#7c3aed','bg-purple-50'],
];
foreach($cards as $c): ?>
<div class="stat-card bg-white rounded-2xl p-5">
    <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-3 <?=$c[4]?>">
        <svg class="w-5 h-5" style="color:<?=$c[3]?>" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$c[2]?>"/></svg>
    </div>
    <div class="text-xl font-bold text-gray-900"><?=$c[1]?></div>
    <div class="text-gray-400 text-xs mt-1"><?=$c[0]?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Alert Cards -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <a href="deposits.php" class="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center gap-4 hover:shadow-md transition">
        <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
            <span class="font-bold text-amber-700 text-xl"><?=$pendingDep?></span>
        </div>
        <div>
            <div class="font-medium text-amber-800">Pending Deposits</div>
            <div class="text-amber-600 text-xs">Awaiting verification</div>
        </div>
    </a>
    <a href="withdrawals.php" class="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center gap-4 hover:shadow-md transition">
        <div class="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
            <span class="font-bold text-blue-700 text-xl"><?=$pendingWd?></span>
        </div>
        <div>
            <div class="font-medium text-blue-800">Pending Withdrawals</div>
            <div class="text-blue-600 text-xs">Awaiting approval</div>
        </div>
    </a>
    <a href="kyc.php" class="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex items-center gap-4 hover:shadow-md transition">
        <div class="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
            <span class="font-bold text-purple-700 text-xl"><?=$kycPending?></span>
        </div>
        <div>
            <div class="font-medium text-purple-800">KYC Reviews</div>
            <div class="text-purple-600 text-xs">Documents to review</div>
        </div>
    </a>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    <!-- Chart -->
    <div class="lg:col-span-2 bg-white rounded-2xl p-6 stat-card">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-display font-bold text-gray-900">Monthly Deposit Volume</h2>
            <span class="badge-gold px-3 py-1 rounded-full text-xs"><?=$monthlyRate?>% Monthly Return</span>
        </div>
        <canvas id="depChart" height="160"></canvas>
    </div>

    <!-- Quick Actions -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Quick Actions</h2>
        <div class="space-y-3">
            <a href="profits.php" class="btn-gold w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white text-sm font-medium">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10"/></svg>
                Distribute Monthly Profit
            </a>
            <a href="deposits.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium bg-green-50 text-green-700 hover:bg-green-100 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Verify Pending Deposits
            </a>
            <a href="withdrawals.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium bg-blue-50 text-blue-700 hover:bg-blue-100 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H9m6 0l-3-3m3 3l-3 3"/></svg>
                Process Withdrawals
            </a>
            <a href="kyc.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium bg-purple-50 text-purple-700 hover:bg-purple-100 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4z"/></svg>
                Review KYC Documents
            </a>
            <a href="settings.php" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium bg-gray-50 text-gray-700 hover:bg-gray-100 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                System Settings
            </a>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Recent Deposits -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <div class="flex justify-between items-center mb-4">
            <h2 class="font-display font-bold text-gray-900">Recent Deposits</h2>
            <a href="deposits.php" class="text-xs" style="color:var(--gold-dark)">View All →</a>
        </div>
        <div class="space-y-3">
        <?php foreach($recentDep as $d):
            $badges=['pending'=>'badge-yellow','verified'=>'badge-green','rejected'=>'badge-red'];
        ?>
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full gold-gradient flex items-center justify-center text-white text-xs font-bold flex-shrink-0"><?=strtoupper(substr($d['name'],0,2))?></div>
            <div class="flex-1 min-w-0">
                <div class="text-sm font-medium text-gray-900 truncate"><?=htmlspecialchars($d['name'])?></div>
                <div class="text-xs text-gray-400"><?=date('M j, H:i',strtotime($d['created_at']))?></div>
            </div>
            <div class="text-right">
                <div class="font-semibold text-gray-900 text-sm">$<?=number_format($d['amount'],2)?></div>
                <span class="<?=$badges[$d['status']]?> px-1.5 py-0.5 rounded-full text-xs"><?=ucfirst($d['status'])?></span>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>

    <!-- Recent Withdrawals -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <div class="flex justify-between items-center mb-4">
            <h2 class="font-display font-bold text-gray-900">Recent Withdrawals</h2>
            <a href="withdrawals.php" class="text-xs" style="color:var(--gold-dark)">View All →</a>
        </div>
        <div class="space-y-3">
        <?php foreach($recentWd as $w):
            $badges=['pending'=>'badge-yellow','approved'=>'badge-green','rejected'=>'badge-red'];
        ?>
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xs font-bold flex-shrink-0"><?=strtoupper(substr($w['name'],0,2))?></div>
            <div class="flex-1 min-w-0">
                <div class="text-sm font-medium text-gray-900 truncate"><?=htmlspecialchars($w['name'])?></div>
                <div class="text-xs text-gray-400"><?=date('M j, H:i',strtotime($w['created_at']))?></div>
            </div>
            <div class="text-right">
                <div class="font-semibold text-red-600 text-sm">-$<?=number_format($w['amount'],2)?></div>
                <span class="<?=$badges[$w['status']]?> px-1.5 py-0.5 rounded-full text-xs"><?=ucfirst($w['status'])?></span>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
const depData = <?=json_encode($depChart)?>;
new Chart(document.getElementById('depChart').getContext('2d'),{
    type:'bar',
    data:{
        labels: depData.map(d=>d.m),
        datasets:[{
            label:'Verified Deposits ($)',
            data: depData.map(d=>parseFloat(d.total)),
            backgroundColor:'rgba(201,168,76,0.2)',
            borderColor:'#C9A84C',
            borderWidth:2,
            borderRadius:6,
        }]
    },
    options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'#f5f5f5'}}}}
});
</script>

<?php include 'footer.php'; ?>
