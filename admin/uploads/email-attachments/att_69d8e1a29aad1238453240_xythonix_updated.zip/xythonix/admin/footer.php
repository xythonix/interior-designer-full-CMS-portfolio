    </main>
</div>

<div id="toast" class="toast bg-gray-900 text-white px-5 py-3 rounded-xl shadow-xl flex items-center gap-3">
    <svg id="toast-icon" class="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    <span id="toast-msg"></span>
</div>

<script>
function showToast(msg, type='success'){
    const colors={success:'text-green-400',error:'text-red-400',info:'text-blue-400',warning:'text-yellow-400'};
    const paths={success:'M5 13l4 4L19 7',error:'M6 18L18 6M6 6l12 12',info:'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',warning:'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'};
    $('#toast-icon').attr('class','w-5 h-5 '+(colors[type]||colors.success));
    $('#toast-icon path').attr('d',paths[type]||paths.success);
    $('#toast-msg').text(msg);
    $('#toast').addClass('show');
    setTimeout(()=>$('#toast').removeClass('show'),3500);
}
function openModal(id){$('#'+id).addClass('active');}
function closeModal(id){$('#'+id).removeClass('active');}
$('.modal-overlay').click(function(e){if($(e.target).hasClass('modal-overlay'))$(this).removeClass('active');});
</script>
</body>
</html>
