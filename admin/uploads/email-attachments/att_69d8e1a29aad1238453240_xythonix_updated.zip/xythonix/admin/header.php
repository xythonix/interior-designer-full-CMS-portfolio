<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$pageTitle ?? 'Admin'?> – Xythonix Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *{font-family:'DM Sans',sans-serif;}
        .font-display{font-family:'Playfair Display',serif;}
        :root{--gold:#C9A84C;--gold-light:#F0D080;--gold-dark:#9A7A2E;--navy:#0A1628;--navy-mid:#142240;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),var(--gold-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(201,168,76,0.35);}
        .admin-sidebar{background:linear-gradient(180deg,#0d1b2e 0%,#0A1628 100%);width:250px;min-height:100vh;}
        .nav-link{transition:all 0.2s;border-radius:8px;}
        .nav-link:hover,.nav-link.active{background:rgba(201,168,76,0.12);color:#F0D080;}
        .nav-link.active{border-left:3px solid var(--gold);padding-left:13px;}
        .stat-card{border:1px solid #f0f0f0;transition:all 0.3s;}
        .stat-card:hover{box-shadow:0 8px 25px rgba(0,0,0,0.07);transform:translateY(-2px);}
        .badge-green{background:#dcfce7;color:#16a34a;}
        .badge-yellow{background:#fef9c3;color:#854d0e;}
        .badge-red{background:#fee2e2;color:#dc2626;}
        .badge-blue{background:#dbeafe;color:#1d4ed8;}
        .badge-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:white;}
        .input-field{border:2px solid #e5e7eb;transition:all 0.3s;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 3px rgba(201,168,76,0.1);}
        .modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);backdrop-filter:blur(4px);z-index:100;align-items:center;justify-content:center;}
        .modal-overlay.active{display:flex;}
        .toast{position:fixed;bottom:24px;right:24px;z-index:999;transform:translateY(20px);opacity:0;transition:all 0.4s;}
        .toast.show{transform:translateY(0);opacity:1;}
        ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-thumb{background:var(--gold);border-radius:3px;}
    </style>
</head>
<body class="bg-gray-50 flex">

<div class="admin-sidebar flex-shrink-0 flex flex-col">
    <div class="p-5 border-b border-white/10">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl gold-gradient flex items-center justify-center">
                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
            </div>
            <div>
                <div class="font-display text-sm font-bold text-white">Xythonix</div>
                <div class="text-red-300 text-xs">Admin Panel</div>
            </div>
        </div>
    </div>
    <nav class="flex-1 p-3 space-y-0.5 overflow-y-auto">
        <?php
        $cp = basename($_SERVER['PHP_SELF']);
        $navs = [
            ['dashboard.php','Dashboard','M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'],
            ['deposits.php','Deposits','M12 4v16m8-8H4'],
            ['withdrawals.php','Withdrawals','M15 12H9m6 0l-3-3m3 3l-3 3'],
            ['profits.php','Profit Management','M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10'],
            ['users.php','User Management','M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z'],
            ['kyc.php','KYC Reviews','M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4z'],
            ['settings.php','Settings','M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z'],
        ];
        foreach($navs as $n):
        $act=$cp===$n[0]?'active':'';
        ?>
        <a href="<?=$n[0]?>" class="nav-link <?=$act?> flex items-center gap-3 px-3 py-2.5 text-sm text-white/50">
            <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$n[2]?>"/></svg>
            <?=$n[1]?>
        </a>
        <?php endforeach; ?>
    </nav>
    <div class="p-3 border-t border-white/10">
        <a href="../pages/logout.php" class="flex items-center gap-3 px-3 py-2 text-sm text-white/30 hover:text-red-400 rounded-lg hover:bg-red-500/10 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
            Sign Out
        </a>
    </div>
</div>

<div class="flex-1 flex flex-col min-h-screen overflow-x-hidden">
    <header class="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between sticky top-0 z-20">
        <h1 class="font-display text-lg font-bold text-gray-900"><?=$pageTitle?></h1>
        <div class="flex items-center gap-3">
            <a href="../pages/dashboard.php" class="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                User View
            </a>
            <div class="w-8 h-8 rounded-full gold-gradient flex items-center justify-center text-white text-xs font-bold">A</div>
        </div>
    </header>
    <main class="flex-1 p-6">
