<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'Profit Management';
$db = getDB();

$currentMonth = date('Y-m');
$monthlyRate  = getSetting('monthly_profit_percent');

// Existing profit records
$profitHistory = $db->query("SELECT mp.*,u.name as admin_name FROM monthly_profits mp LEFT JOIN users u ON mp.applied_by=u.id ORDER BY mp.month_year DESC LIMIT 24")->fetchAll();

// Preview: users with verified balance
$eligibleUsers = $db->query("SELECT id, name, email, invested_balance, profit_balance, (invested_balance+profit_balance) as current_balance FROM users WHERE role='user' AND status='active' AND invested_balance > 0 ORDER BY (invested_balance+profit_balance) DESC")->fetchAll();

// Check if current month already applied
$alreadyApplied = $db->prepare("SELECT id FROM monthly_profits WHERE month_year=? AND status='applied'");
$alreadyApplied->execute([$currentMonth]);
$isApplied = (bool)$alreadyApplied->fetch();

include 'header.php';
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    <!-- Set Profit Rate -->
    <div class="lg:col-span-1 bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Monthly Profit Rate</h2>
        <div class="text-center mb-5">
            <div class="font-display text-5xl font-bold gold-text"><?=$monthlyRate?>%</div>
            <div class="text-gray-400 text-sm mt-1">Current Rate — <?=date('F Y')?></div>
        </div>
        <form id="rateForm" class="space-y-3">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Update Rate (%)</label>
                <input type="number" name="rate" value="<?=$monthlyRate?>" step="0.01" min="0" max="100" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 text-center font-bold text-lg" required>
            </div>
            <button type="submit" class="btn-gold w-full py-3 rounded-xl text-white font-medium">Update Rate</button>
        </form>

        <div class="mt-6 pt-5 border-t border-gray-100">
            <div class="text-gray-500 text-xs mb-3">Month: <?=$currentMonth?></div>
            <?php if($isApplied): ?>
            <div class="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
                <div class="text-green-700 font-medium text-sm">✓ Profit Distributed</div>
                <div class="text-green-500 text-xs mt-1">Already applied this month</div>
            </div>
            <?php else: ?>
            <button onclick="openModal('distributeModal')" class="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-medium transition text-sm flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                Distribute <?=$currentMonth?> Profit
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Preview / Eligible Users -->
    <div class="lg:col-span-2 bg-white rounded-2xl p-6 stat-card">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-display font-bold text-gray-900">Eligible Users Preview</h2>
            <span class="badge-gold px-3 py-1 rounded-full text-xs"><?=count($eligibleUsers)?> users · Rate: <?=$monthlyRate?>%</span>
        </div>
        <?php if(count($eligibleUsers)===0): ?>
        <div class="text-center py-10 text-gray-400">
            <p>No users with invested balance yet</p>
        </div>
        <?php else: ?>
        <?php
        $totalToDistribute = 0;
        foreach($eligibleUsers as $eu) {
            $totalToDistribute += ($eu['current_balance'] * $monthlyRate / 100);
        }
        ?>
        <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-3 mb-4 flex items-center justify-between">
            <span class="text-yellow-700 text-sm font-medium">Total to distribute this month:</span>
            <span class="font-display font-bold text-yellow-700">$<?=number_format($totalToDistribute,2)?></span>
        </div>
        <div class="overflow-x-auto max-h-64 overflow-y-auto">
            <table class="w-full text-sm">
                <thead class="sticky top-0 bg-white"><tr class="border-b border-gray-100">
                    <th class="text-left py-2 text-gray-400 font-medium">User</th>
                    <th class="text-right py-2 text-gray-400 font-medium">Invest Balance</th>
                    <th class="text-right py-2 text-gray-400 font-medium">Profit Bal.</th>
                    <th class="text-right py-2 text-gray-400 font-medium">Current Total</th>
                    <th class="text-right py-2 text-gray-400 font-medium">Profit (<?=$monthlyRate?>%)</th>
                </tr></thead>
                <tbody>
                <?php foreach($eligibleUsers as $eu):
                    $profitAmt = $eu['current_balance'] * $monthlyRate / 100;
                ?>
                <tr class="border-b border-gray-50">
                    <td class="py-2">
                        <div class="font-medium text-gray-900"><?=htmlspecialchars($eu['name'])?></div>
                        <div class="text-gray-400 text-xs"><?=htmlspecialchars($eu['email'])?></div>
                    </td>
                    <td class="py-2 text-right text-gray-600">$<?=number_format($eu['invested_balance'],2)?></td>
                    <td class="py-2 text-right text-gray-600">$<?=number_format($eu['profit_balance'],2)?></td>
                    <td class="py-2 text-right font-semibold text-gray-900">$<?=number_format($eu['current_balance'],2)?></td>
                    <td class="py-2 text-right font-bold text-green-600">+$<?=number_format($profitAmt,2)?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Profit History -->
<div class="bg-white rounded-2xl p-6 stat-card">
    <h2 class="font-display font-bold text-gray-900 mb-4">Distribution History</h2>
    <?php if(count($profitHistory)===0): ?>
    <div class="text-center py-10 text-gray-400">No distributions yet</div>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead><tr class="border-b border-gray-100">
                <th class="text-left py-3 text-gray-400 font-medium">Month</th>
                <th class="text-right py-3 text-gray-400 font-medium">Rate</th>
                <th class="text-right py-3 text-gray-400 font-medium">Total Distributed</th>
                <th class="text-left py-3 text-gray-400 font-medium">Applied By</th>
                <th class="text-left py-3 text-gray-400 font-medium">Applied At</th>
                <th class="text-left py-3 text-gray-400 font-medium">Status</th>
            </tr></thead>
            <tbody>
            <?php foreach($profitHistory as $ph): ?>
            <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                <td class="py-3 font-medium text-gray-900"><?=$ph['month_year']?></td>
                <td class="py-3 text-right"><span class="badge-gold px-2 py-0.5 rounded-full text-xs"><?=$ph['profit_percent']?>%</span></td>
                <td class="py-3 text-right font-semibold text-green-600">$<?=number_format($ph['total_distributed'],2)?></td>
                <td class="py-3 text-gray-500"><?=htmlspecialchars($ph['admin_name']??'System')?></td>
                <td class="py-3 text-gray-400"><?=$ph['applied_at']?date('M j, Y H:i',strtotime($ph['applied_at'])):'—'?></td>
                <td class="py-3"><span class="<?=$ph['status']==='applied'?'badge-green':'badge-yellow'?> px-2 py-1 rounded-full text-xs"><?=ucfirst($ph['status'])?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Distribute Confirmation Modal -->
<div id="distributeModal" class="modal-overlay">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md mx-4 shadow-2xl">
        <h3 class="font-display font-bold text-gray-900 mb-2">Confirm Profit Distribution</h3>
        <p class="text-gray-500 text-sm mb-5">You are about to distribute <strong><?=$monthlyRate?>%</strong> monthly profit to <strong><?=count($eligibleUsers)?></strong> users for <strong><?=$currentMonth?></strong>.</p>
        <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-5">
            <div class="text-yellow-800 text-sm font-medium mb-1">This action will:</div>
            <ul class="text-yellow-700 text-xs space-y-1">
                <li>• Calculate profit on each user's <strong>current total balance</strong> (invested + existing profit)</li>
                <li>• Add profit amounts to each user's profit balance</li>
                <li>• This month's profit becomes the new base for next month</li>
                <li>• This action <strong>cannot be undone</strong></li>
            </ul>
        </div>
        <div class="flex gap-3">
            <button onclick="distributeProfit()" class="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition">✓ Confirm Distribution</button>
            <button onclick="closeModal('distributeModal')" class="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition">Cancel</button>
        </div>
    </div>
</div>

<script>
$('#rateForm').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'update_profit_rate', rate:$('[name="rate"]').val()},
        dataType:'json',
        success:r=>{ if(r.success){showToast('Profit rate updated!','success');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
});

function distributeProfit(){
    const btn=$('#distributeModal button:first');
    btn.text('Distributing...').prop('disabled',true);
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'distribute_profit'},
        dataType:'json',
        success:r=>{
            if(r.success){
                showToast(r.message,'success');
                closeModal('distributeModal');
                setTimeout(()=>location.reload(),1800);
            }else{
                showToast(r.error||'Error','error');
                btn.text('✓ Confirm Distribution').prop('disabled',false);
            }
        }
    });
}
</script>

<?php include 'footer.php'; ?>
