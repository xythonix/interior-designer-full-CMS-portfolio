<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'User Management';
$db = getDB();

$search = $_GET['search'] ?? '';
$where  = '';
$params = [];
if($search) {
    $where  = "WHERE u.role='user' AND (u.name LIKE ? OR u.email LIKE ?)";
    $params = ["%$search%","%$search%"];
} else {
    $where  = "WHERE u.role='user'";
}
$users = $db->prepare("SELECT u.*, (SELECT COUNT(*) FROM deposits WHERE user_id=u.id AND status='verified') as dep_count FROM users u $where ORDER BY u.created_at DESC");
$users->execute($params);
$users = $users->fetchAll();

include 'header.php';
?>

<div class="bg-white rounded-2xl p-5 mb-5 stat-card flex items-center gap-4">
    <div class="flex-1">
        <form method="GET" class="flex gap-3">
            <input type="text" name="search" value="<?=htmlspecialchars($search)?>" placeholder="Search by name or email..." class="input-field flex-1 px-4 py-2.5 rounded-xl text-gray-900 text-sm">
            <button type="submit" class="btn-gold px-5 py-2.5 rounded-xl text-white text-sm font-medium">Search</button>
            <?php if($search): ?><a href="users.php" class="px-4 py-2.5 rounded-xl border border-gray-200 text-gray-500 text-sm hover:border-gray-400 transition">Clear</a><?php endif; ?>
        </form>
    </div>
    <div class="text-gray-400 text-sm"><?=count($users)?> users</div>
</div>

<div class="bg-white rounded-2xl stat-card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead><tr class="bg-gray-50 border-b border-gray-100">
                <th class="text-left px-5 py-3 text-gray-400 font-medium">User</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">KYC</th>
                <th class="text-right px-5 py-3 text-gray-400 font-medium">Invested</th>
                <th class="text-right px-5 py-3 text-gray-400 font-medium">Profit</th>
                <th class="text-right px-5 py-3 text-gray-400 font-medium">Withdrawn</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Status</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Joined</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Actions</th>
            </tr></thead>
            <tbody>
            <?php if(count($users)===0): ?>
            <tr><td colspan="8" class="text-center py-12 text-gray-400">No users found</td></tr>
            <?php else: foreach($users as $u):
                $kycBadge=['none'=>'badge-red','pending'=>'badge-yellow','verified'=>'badge-green','rejected'=>'badge-red'];
                $statusBadge=['active'=>'badge-green','suspended'=>'badge-red','pending'=>'badge-yellow'];
            ?>
            <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                <td class="px-5 py-4">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-full gold-gradient flex items-center justify-center text-white text-xs font-bold flex-shrink-0"><?=strtoupper(substr($u['name'],0,2))?></div>
                        <div>
                            <div class="font-medium text-gray-900"><?=htmlspecialchars($u['name'])?></div>
                            <div class="text-gray-400 text-xs"><?=htmlspecialchars($u['email'])?></div>
                        </div>
                    </div>
                </td>
                <td class="px-5 py-4"><span class="<?=$kycBadge[$u['kyc_status']]?> px-2 py-0.5 rounded-full text-xs"><?=ucfirst($u['kyc_status'])?></span></td>
                <td class="px-5 py-4 text-right font-semibold text-gray-900">$<?=number_format($u['invested_balance'],2)?></td>
                <td class="px-5 py-4 text-right font-semibold text-green-600">$<?=number_format($u['profit_balance'],2)?></td>
                <td class="px-5 py-4 text-right text-gray-500">$<?=number_format($u['total_withdrawn'],2)?></td>
                <td class="px-5 py-4"><span class="<?=$statusBadge[$u['status']]?> px-2 py-0.5 rounded-full text-xs"><?=ucfirst($u['status'])?></span></td>
                <td class="px-5 py-4 text-gray-400"><?=date('M j, Y',strtotime($u['created_at']))?></td>
                <td class="px-5 py-4">
                    <div class="flex gap-2">
                        <button onclick="openUserModal(<?=json_encode($u)?>)" class="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
                        <?php if($u['status']==='active'): ?>
                        <button onclick="toggleUser(<?=$u['id']?>,'suspended')" class="bg-red-50 text-red-600 hover:bg-red-100 px-3 py-1.5 rounded-lg text-xs font-medium transition">Suspend</button>
                        <?php else: ?>
                        <button onclick="toggleUser(<?=$u['id']?>,'active')" class="bg-green-50 text-green-600 hover:bg-green-100 px-3 py-1.5 rounded-lg text-xs font-medium transition">Activate</button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- User Edit Modal -->
<div id="userModal" class="modal-overlay">
    <div class="bg-white rounded-2xl p-6 w-full max-w-lg mx-4 shadow-2xl max-h-screen overflow-y-auto">
        <div class="flex items-center justify-between mb-5">
            <h3 class="font-display font-bold text-gray-900">Edit User</h3>
            <button onclick="closeModal('userModal')" class="text-gray-400 hover:text-gray-600">✕</button>
        </div>
        <form id="editUserForm" class="space-y-4">
            <input type="hidden" id="eu_id" name="user_id">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Name</label>
                    <input type="text" id="eu_name" name="name" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Email</label>
                    <input type="email" id="eu_email" name="email" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Invested Balance ($)</label>
                    <input type="number" id="eu_invested" name="invested_balance" step="0.01" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Profit Balance ($)</label>
                    <input type="number" id="eu_profit" name="profit_balance" step="0.01" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">KYC Status</label>
                <select id="eu_kyc" name="kyc_status" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                    <option value="none">None</option>
                    <option value="pending">Pending</option>
                    <option value="verified">Verified</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Status</label>
                <select id="eu_status" name="status" class="input-field w-full px-3 py-2.5 rounded-xl text-sm text-gray-900">
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="pending">Pending</option>
                </select>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="flex-1 btn-gold py-3 rounded-xl text-white font-medium">Save Changes</button>
                <button type="button" onclick="closeModal('userModal')" class="flex-1 bg-gray-100 py-3 rounded-xl text-gray-700 font-medium hover:bg-gray-200 transition">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function openUserModal(u){
    $('#eu_id').val(u.id);
    $('#eu_name').val(u.name);
    $('#eu_email').val(u.email);
    $('#eu_invested').val(u.invested_balance);
    $('#eu_profit').val(u.profit_balance);
    $('#eu_kyc').val(u.kyc_status);
    $('#eu_status').val(u.status);
    openModal('userModal');
}

$('#editUserForm').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:$(this).serialize()+'&action=update_user',
        dataType:'json',
        success:r=>{ if(r.success){showToast('User updated!','success');closeModal('userModal');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
});

function toggleUser(id, status){
    if(!confirm('Change user status to '+status+'?')) return;
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'toggle_user_status', user_id:id, status:status},
        dataType:'json',
        success:r=>{ if(r.success){showToast('Status updated','success');setTimeout(()=>location.reload(),1000);}else showToast(r.error,'error'); }
    });
}
</script>

<?php include 'footer.php'; ?>
