<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'Withdrawal Management';
$db = getDB();

$filter = $_GET['status'] ?? 'all';
$where  = $filter !== 'all' ? "WHERE w.status='$filter'" : '';
$withdrawals = $db->query("SELECT w.*,u.name,u.email,u.wallet_address FROM withdrawals w JOIN users u ON w.user_id=u.id $where ORDER BY w.created_at DESC")->fetchAll();
$counts = $db->query("SELECT status, COUNT(*) as cnt FROM withdrawals GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

include 'header.php';
?>

<div class="flex gap-2 mb-6 flex-wrap">
    <?php foreach(['all'=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$v):
        $total = $k==='all'?array_sum($counts):($counts[$k]??0);
        $active=$filter===$k;
    ?>
    <a href="?status=<?=$k?>" class="px-4 py-2 rounded-xl text-sm font-medium transition <?=$active?'text-white':'bg-white text-gray-500 border border-gray-200 hover:border-yellow-400'?>" <?=$active?'style="background:var(--gold)"':''?>>
        <?=$v?> <span class="ml-1 opacity-70">(<?=$total?>)</span>
    </a>
    <?php endforeach; ?>
</div>

<div class="bg-white rounded-2xl stat-card overflow-hidden">
    <div class="p-5 border-b border-gray-100 flex items-center justify-between">
        <h2 class="font-display font-bold text-gray-900">Withdrawals</h2>
        <span class="text-gray-400 text-sm"><?=count($withdrawals)?> records</span>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead><tr class="bg-gray-50 border-b border-gray-100">
                <th class="text-left px-5 py-3 text-gray-400 font-medium">User</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Amount</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Type</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Wallet</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Date</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Status</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Actions</th>
            </tr></thead>
            <tbody>
            <?php if(count($withdrawals)===0): ?>
            <tr><td colspan="7" class="text-center py-12 text-gray-400">No withdrawals found</td></tr>
            <?php else: foreach($withdrawals as $w):
                $badges=['pending'=>'badge-yellow','approved'=>'badge-green','rejected'=>'badge-red'];
            ?>
            <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                <td class="px-5 py-4">
                    <div class="font-medium text-gray-900"><?=htmlspecialchars($w['name'])?></div>
                    <div class="text-gray-400 text-xs"><?=htmlspecialchars($w['email'])?></div>
                </td>
                <td class="px-5 py-4 font-semibold text-red-600">$<?=number_format($w['amount'],2)?></td>
                <td class="px-5 py-4 text-gray-500 capitalize"><?=$w['withdrawal_type']?></td>
                <td class="px-5 py-4">
                    <div class="font-mono text-xs text-gray-500 max-w-xs truncate" title="<?=htmlspecialchars($w['wallet_to'])?>"><?=$w['wallet_to']?></div>
                </td>
                <td class="px-5 py-4 text-gray-500"><?=date('M j, Y H:i',strtotime($w['created_at']))?></td>
                <td class="px-5 py-4"><span class="<?=$badges[$w['status']]?> px-2 py-1 rounded-full text-xs font-medium"><?=ucfirst($w['status'])?></span></td>
                <td class="px-5 py-4">
                    <?php if($w['status']==='pending'): ?>
                    <div class="flex gap-2">
                        <button onclick="processWithdrawal(<?=$w['id']?>,'approve')" class="bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1.5 rounded-lg text-xs font-medium transition">Approve</button>
                        <button onclick="processWithdrawal(<?=$w['id']?>,'reject')" class="bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg text-xs font-medium transition">Reject</button>
                    </div>
                    <?php elseif($w['status']==='approved'): ?>
                    <span class="text-green-500 text-xs">✓ Processed</span>
                    <?php else: ?>
                    <span class="text-red-400 text-xs">✗ Rejected</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function processWithdrawal(id, action){
    if(!confirm('Are you sure you want to '+action+' this withdrawal?')) return;
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'process_withdrawal', withdrawal_id:id, decision:action},
        dataType:'json',
        success:r=>{ if(r.success){showToast(r.message,'success');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
}
</script>

<?php include 'footer.php'; ?>
