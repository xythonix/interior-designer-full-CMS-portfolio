<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'Deposit Management';
$db = getDB();

$filter = $_GET['status'] ?? 'all';
$where  = $filter !== 'all' ? "WHERE d.status='$filter'" : '';
$deposits = $db->query("SELECT d.*,u.name,u.email,u.kyc_status FROM deposits d JOIN users u ON d.user_id=u.id $where ORDER BY d.created_at DESC")->fetchAll();

$counts = $db->query("SELECT status, COUNT(*) as cnt FROM deposits GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

include 'header.php';
?>

<!-- Filter Tabs -->
<div class="flex gap-2 mb-6 flex-wrap">
    <?php foreach(['all'=>'All','pending'=>'Pending','verified'=>'Verified','rejected'=>'Rejected'] as $k=>$v):
        $total = $k==='all' ? array_sum($counts) : ($counts[$k]??0);
        $active = $filter===$k;
    ?>
    <a href="?status=<?=$k?>" class="px-4 py-2 rounded-xl text-sm font-medium transition <?=$active?'text-white':'bg-white text-gray-500 border border-gray-200 hover:border-yellow-400'?>" <?=$active?'style="background:var(--gold)"':''?>>
        <?=$v?> <span class="ml-1 opacity-70">(<?=$total?>)</span>
    </a>
    <?php endforeach; ?>
</div>

<div class="bg-white rounded-2xl stat-card overflow-hidden">
    <div class="p-5 border-b border-gray-100 flex items-center justify-between">
        <h2 class="font-display font-bold text-gray-900">Deposits</h2>
        <span class="text-gray-400 text-sm"><?=count($deposits)?> records</span>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead><tr class="bg-gray-50 border-b border-gray-100">
                <th class="text-left px-5 py-3 text-gray-400 font-medium">User</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Amount</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Tx Hash</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Date</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Status</th>
                <th class="text-left px-5 py-3 text-gray-400 font-medium">Actions</th>
            </tr></thead>
            <tbody>
            <?php if(count($deposits)===0): ?>
            <tr><td colspan="6" class="text-center py-12 text-gray-400">No deposits found</td></tr>
            <?php else: foreach($deposits as $d):
                $badges=['pending'=>'badge-yellow','verified'=>'badge-green','rejected'=>'badge-red'];
            ?>
            <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                <td class="px-5 py-4">
                    <div class="font-medium text-gray-900"><?=htmlspecialchars($d['name'])?></div>
                    <div class="text-gray-400 text-xs"><?=htmlspecialchars($d['email'])?></div>
                </td>
                <td class="px-5 py-4 font-semibold text-gray-900">$<?=number_format($d['amount'],2)?></td>
                <td class="px-5 py-4">
                    <?php if($d['txn_hash']): ?>
                    <div class="font-mono text-xs text-gray-500 max-w-xs truncate" title="<?=htmlspecialchars($d['txn_hash'])?>"><?=$d['txn_hash']?></div>
                    <?php else: ?><span class="text-gray-300">—</span><?php endif; ?>
                </td>
                <td class="px-5 py-4 text-gray-500"><?=date('M j, Y H:i',strtotime($d['created_at']))?></td>
                <td class="px-5 py-4"><span class="<?=$badges[$d['status']]?> px-2 py-1 rounded-full text-xs font-medium"><?=ucfirst($d['status'])?></span></td>
                <td class="px-5 py-4">
                    <?php if($d['status']==='pending'): ?>
                    <div class="flex gap-2">
                        <button onclick="processDeposit(<?=$d['id']?>,'verify')" class="bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1.5 rounded-lg text-xs font-medium transition">Verify</button>
                        <button onclick="openRejectModal(<?=$d['id']?>,'deposit')" class="bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg text-xs font-medium transition">Reject</button>
                    </div>
                    <?php elseif($d['status']==='verified'): ?>
                    <span class="text-green-400 text-xs">✓ Verified</span>
                    <?php else: ?>
                    <span class="text-red-400 text-xs">✗ Rejected</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md mx-4 shadow-2xl">
        <h3 class="font-display font-bold text-gray-900 mb-4">Reject Deposit</h3>
        <input type="hidden" id="reject_id">
        <input type="hidden" id="reject_entity">
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Reason for rejection</label>
            <textarea id="reject_reason" rows="3" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" placeholder="Enter reason..."></textarea>
        </div>
        <div class="flex gap-3">
            <button onclick="submitReject()" class="flex-1 bg-red-500 text-white py-3 rounded-xl font-medium hover:bg-red-600 transition">Reject</button>
            <button onclick="closeModal('rejectModal')" class="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition">Cancel</button>
        </div>
    </div>
</div>

<script>
function processDeposit(id, action){
    if(!confirm('Are you sure you want to '+action+' this deposit?')) return;
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'process_deposit', deposit_id:id, decision:action},
        dataType:'json',
        success:r=>{ if(r.success){showToast(r.message,'success');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
}
function openRejectModal(id, entity){
    $('#reject_id').val(id); $('#reject_entity').val(entity);
    openModal('rejectModal');
}
function submitReject(){
    const id=$('#reject_id').val(), reason=$('#reject_reason').val(), entity=$('#reject_entity').val();
    $.ajax({
        url:'admin_ajax.php', method:'POST',
        data:{action:'process_deposit', deposit_id:id, decision:'reject', reason:reason},
        dataType:'json',
        success:r=>{ if(r.success){showToast('Rejected','success');closeModal('rejectModal');setTimeout(()=>location.reload(),1200);}else showToast(r.error,'error'); }
    });
}
</script>

<?php include 'footer.php'; ?>
