<?php
require_once '../includes/config.php';
requireLogin(); requireAdmin();
$pageTitle = 'System Settings';
$db = getDB();

include 'header.php';
?>

<div class="max-w-2xl mx-auto space-y-6">
    <!-- Wallet & Deposits -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-5">Wallet & Deposits</h2>
        <form id="walletForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">System USDT Wallet (BEP2)</label>
                <input type="text" name="system_wallet" value="<?=htmlspecialchars(getSetting('system_wallet')??'')?>" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 font-mono text-sm" placeholder="BEP2 wallet address">
                <p class="text-gray-400 text-xs mt-1">Users send deposits to this address</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Minimum Deposit ($)</label>
                <input type="number" name="min_deposit" value="<?=getSetting('min_deposit')?>" step="1" min="1" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
            </div>
            <button type="submit" class="btn-gold px-6 py-3 rounded-xl text-white font-medium">Save Wallet Settings</button>
        </form>
    </div>

    <!-- Profit & Withdrawal -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-5">Profit & Withdrawal</h2>
        <form id="profitForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Monthly Profit Rate (%)</label>
                <input type="number" name="monthly_profit_percent" value="<?=getSetting('monthly_profit_percent')?>" step="0.01" min="0" max="100" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
                <p class="text-gray-400 text-xs mt-1">Applied to user's full balance (invested + existing profit)</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Minimum Withdrawal ($)</label>
                <input type="number" name="min_withdrawal" value="<?=getSetting('min_withdrawal')?>" step="1" min="1" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Withdrawal Fee (%)</label>
                <input type="number" name="withdrawal_fee_percent" value="<?=getSetting('withdrawal_fee_percent')?>" step="0.01" min="0" max="100" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
            </div>
            <button type="submit" class="btn-gold px-6 py-3 rounded-xl text-white font-medium">Save Profit Settings</button>
        </form>
    </div>

    <!-- Referral -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-5">Referral Program</h2>
        <form id="referralForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Referral Bonus (%)</label>
                <input type="number" name="referral_bonus_percent" value="<?=getSetting('referral_bonus_percent')?>" step="0.01" min="0" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
                <p class="text-gray-400 text-xs mt-1">Bonus credited to referrer when referred user's first deposit is verified</p>
            </div>
            <button type="submit" class="btn-gold px-6 py-3 rounded-xl text-white font-medium">Save Referral Settings</button>
        </form>
    </div>

    <!-- Site Info -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-5">Site Information</h2>
        <form id="siteForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Site Name</label>
                <input type="text" name="site_name" value="<?=htmlspecialchars(getSetting('site_name')??'Xythonix Funds')?>" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Support Email</label>
                <input type="email" name="site_email" value="<?=htmlspecialchars(getSetting('site_email')??'')?>" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
            </div>
            <button type="submit" class="btn-gold px-6 py-3 rounded-xl text-white font-medium">Save Site Settings</button>
        </form>
    </div>
</div>

<script>
function saveSettings(formId, keys){
    $('#'+formId).submit(function(e){
        e.preventDefault();
        const data = {action:'update_settings'};
        keys.forEach(k => data[k] = $('[name="'+k+'"]').val());
        $.ajax({
            url:'admin_ajax.php', method:'POST', data:data, dataType:'json',
            success:r=>r.success?showToast('Settings saved!','success'):showToast(r.error,'error')
        });
    });
}
saveSettings('walletForm',  ['system_wallet','min_deposit']);
saveSettings('profitForm',  ['monthly_profit_percent','min_withdrawal','withdrawal_fee_percent']);
saveSettings('referralForm',['referral_bonus_percent']);
saveSettings('siteForm',    ['site_name','site_email']);
</script>

<?php include 'footer.php'; ?>
