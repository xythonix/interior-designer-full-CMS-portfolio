PHPMAILER REQUIRED
==================
Download PHPMailer from: https://github.com/PHPMailer/PHPMailer

Extract into this directory so the structure is:
  includes/PHPMailer-master/src/PHPMailer.php
  includes/PHPMailer-master/src/SMTP.php
  includes/PHPMailer-master/src/Exception.php

The SMTP API key (xwdukttlyhnjavkq) is already set in includes/config.php
under MAIL_PASSWORD. Update MAIL_HOST, MAIL_PORT, MAIL_USERNAME, and
MAIL_FROM to match your email provider (Gmail, Mailgun, SendGrid, etc.).
