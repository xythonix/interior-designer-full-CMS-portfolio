<?php
require_once 'config.php';
requireLogin();
header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$db = getDB();
$userId = $_SESSION['user_id'];

switch($action) {
    case 'submit_deposit':
        $amount = (float)($_POST['amount'] ?? 0);
        $txHash = trim($_POST['txn_hash'] ?? '');
        $walletFrom = trim($_POST['wallet_from'] ?? '');
        $minDeposit = (float)getSetting('min_deposit');
        $u = getCurrentUser();
        
        if($u['kyc_status'] !== 'verified') jsonResponse(['success'=>false,'error'=>'KYC verification required.']);
        if($amount < $minDeposit) jsonResponse(['success'=>false,'error'=>"Minimum deposit is \$$minDeposit."]);
        if(empty($txHash)) jsonResponse(['success'=>false,'error'=>'Transaction hash is required.']);
        
        // Check duplicate txHash
        $chk = $db->prepare("SELECT id FROM deposits WHERE txn_hash=?");
        $chk->execute([$txHash]);
        if($chk->fetch()) jsonResponse(['success'=>false,'error'=>'This transaction hash has already been submitted.']);
        
        $stmt = $db->prepare("INSERT INTO deposits (user_id, amount, txn_hash, wallet_from, status) VALUES (?,?,?,?,'pending')");
        $stmt->execute([$userId, $amount, $txHash, $walletFrom]);
        $depositId = $db->lastInsertId();
        logTransaction($userId, 'deposit', $amount, 'Deposit submitted - pending verification', $depositId, 'pending');
        jsonResponse(['success'=>true]);
        break;

    case 'submit_withdrawal':
        $amount = (float)($_POST['amount'] ?? 0);
        $walletTo = trim($_POST['wallet_to'] ?? '');
        $type = $_POST['withdrawal_type'] ?? 'profit';
        $minWithdraw = (float)getSetting('min_withdrawal');
        $u = getCurrentUser();
        
        if($u['kyc_status'] !== 'verified') jsonResponse(['success'=>false,'error'=>'KYC verification required.']);
        if(empty($walletTo)) jsonResponse(['success'=>false,'error'=>'Wallet address is required.']);
        if($amount < $minWithdraw) jsonResponse(['success'=>false,'error'=>"Minimum withdrawal is \$$minWithdraw."]);
        
        $maxAvail = $type === 'profit' ? $u['profit_balance'] : ($u['invested_balance'] + $u['profit_balance']);
        if($amount > $maxAvail) jsonResponse(['success'=>false,'error'=>'Amount exceeds available balance.']);
        
        $stmt = $db->prepare("INSERT INTO withdrawals (user_id, amount, wallet_to, withdrawal_type, status) VALUES (?,?,?,?,'pending')");
        $stmt->execute([$userId, $amount, $walletTo, $type]);
        $wdId = $db->lastInsertId();
        logTransaction($userId, 'withdrawal', $amount, 'Withdrawal request pending approval', $wdId, 'pending');
        jsonResponse(['success'=>true]);
        break;

    case 'submit_kyc':
        $docType = sanitize($_POST['doc_type'] ?? '');
        if(empty($docType)) jsonResponse(['success'=>false,'error'=>'Please select document type.']);
        
        $uploadDir = UPLOAD_PATH . 'kyc/' . $userId . '/';
        if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        
        $uploaded = [];
        $files = ['doc_front'=>'front','doc_back'=>'back','doc_selfie'=>'selfie'];
        foreach($files as $field=>$name) {
            if(!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
                if($field==='doc_front'||$field==='doc_selfie') jsonResponse(['success'=>false,'error'=>"Please upload $name image."]);
                continue;
            }
            $file = $_FILES[$field];
            $allowedTypes = ['image/jpeg','image/png','image/jpg','application/pdf'];
            if(!in_array($file['type'],$allowedTypes)) jsonResponse(['success'=>false,'error'=>'Invalid file type. Use JPG, PNG, or PDF.']);
            if($file['size'] > 5*1024*1024) jsonResponse(['success'=>false,'error'=>'File too large. Max 5MB.']);
            
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = $name.'_'.time().'.'.$ext;
            $dest = $uploadDir.$filename;
            if(move_uploaded_file($file['tmp_name'], $dest)) {
                $uploaded[$field] = 'kyc/'.$userId.'/'.$filename;
            }
        }
        
        $stmt = $db->prepare("UPDATE users SET kyc_status='pending', kyc_doc_type=?, kyc_doc_front=?, kyc_doc_back=?, kyc_selfie=?, kyc_submitted_at=NOW() WHERE id=?");
        $stmt->execute([$docType, $uploaded['doc_front']??null, $uploaded['doc_back']??null, $uploaded['doc_selfie']??null, $userId]);
        jsonResponse(['success'=>true]);
        break;

    case 'update_profile':
        $name = sanitize($_POST['name'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $wallet = sanitize($_POST['wallet_address'] ?? '');
        if(empty($name)) jsonResponse(['success'=>false,'error'=>'Name is required.']);
        $db->prepare("UPDATE users SET name=?, phone=?, wallet_address=? WHERE id=?")->execute([$name,$phone,$wallet,$userId]);
        $_SESSION['user_name'] = $name;
        jsonResponse(['success'=>true]);
        break;

    case 'change_password':
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $u = getCurrentUser();
        if(!password_verify($current, $u['password'])) jsonResponse(['success'=>false,'error'=>'Current password is incorrect.']);
        if(strlen($new) < 8) jsonResponse(['success'=>false,'error'=>'New password must be at least 8 characters.']);
        if($new !== $confirm) jsonResponse(['success'=>false,'error'=>'Passwords do not match.']);
        $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$userId]);
        jsonResponse(['success'=>true]);
        break;

    default:
        jsonResponse(['success'=>false,'error'=>'Invalid action.']);
}
?>
