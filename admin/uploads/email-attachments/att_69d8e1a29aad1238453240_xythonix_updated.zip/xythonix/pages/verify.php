<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$status  = 'invalid'; // invalid | expired | already | success
$message = '';

$token = trim($_GET['token'] ?? '');

if(!empty($token)) {
    $db = getDB();

    $stmt = $db->prepare("SELECT ev.*, u.name, u.email, u.email_verified 
                          FROM email_verifications ev
                          JOIN users u ON u.id = ev.user_id
                          WHERE ev.token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch();

    if(!$row) {
        $status  = 'invalid';
        $message = 'This verification link is invalid or has already been used.';
    } elseif($row['email_verified']) {
        $status  = 'already';
        $message = 'Your email has already been verified. Please sign in.';
    } elseif(strtotime($row['expires_at']) < time()) {
        $status  = 'expired';
        $message = 'This verification link has expired. Please register again or request a new link.';
    } else {
        // Mark user as verified and active
        $db->prepare("UPDATE users SET email_verified = 1, status = 'active' WHERE id = ?")->execute([$row['user_id']]);
        // Delete used token
        $db->prepare("DELETE FROM email_verifications WHERE token = ?")->execute([$token]);

        $status  = 'success';
        $message = 'Your email has been verified! You can now sign in to your account.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        :root{--gold:#C9A84C;--gold-light:#F0D080;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold),var(--gold-light));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),var(--gold-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
<div class="bg-white rounded-2xl p-10 max-w-md w-full shadow-sm border border-gray-100 text-center">
    <!-- Logo -->
    <a href="../index.php" class="inline-flex items-center gap-2 mb-8">
        <div class="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center">
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
        </div>
        <span class="font-display text-lg font-bold text-gray-900">Xythonix <span class="gold-text">Funds</span></span>
    </a>

    <?php if($status === 'success'): ?>
    <div class="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
        <svg class="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    </div>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Email Verified!</h1>
    <p class="text-gray-500 mb-8"><?=htmlspecialchars($message)?></p>
    <a href="login.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Sign In to Your Account</a>

    <?php elseif($status === 'already'): ?>
    <div class="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-6">
        <svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Already Verified</h1>
    <p class="text-gray-500 mb-8"><?=htmlspecialchars($message)?></p>
    <a href="login.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Sign In</a>

    <?php elseif($status === 'expired'): ?>
    <div class="w-20 h-20 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-6">
        <svg class="w-10 h-10 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Link Expired</h1>
    <p class="text-gray-500 mb-8"><?=htmlspecialchars($message)?></p>
    <a href="register.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Register Again</a>

    <?php else: ?>
    <div class="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
        <svg class="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Invalid Link</h1>
    <p class="text-gray-500 mb-8"><?=htmlspecialchars($message ?: 'This verification link is not valid.')?></p>
    <a href="../index.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Go Home</a>
    <?php endif; ?>
</div>
</body>
</html>
