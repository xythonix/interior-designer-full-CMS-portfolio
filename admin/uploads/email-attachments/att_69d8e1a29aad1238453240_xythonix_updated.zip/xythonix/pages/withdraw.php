<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Withdraw Funds';
$u = getCurrentUser();
$db = getDB();
$minWithdraw = getSetting('min_withdrawal');
$withdrawFee = getSetting('withdrawal_fee_percent');

$wdStmt = $db->prepare("SELECT * FROM withdrawals WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
$wdStmt->execute([$u['id']]);
$withdrawals = $wdStmt->fetchAll();

$availableProfit = $u['profit_balance'];
$totalAvailable = $u['invested_balance'] + $u['profit_balance'];

include '../includes/header.php';
?>

<div class="max-w-4xl mx-auto">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Balance Overview -->
        <div class="bg-white rounded-2xl p-6 stat-card">
            <h2 class="font-display font-bold text-gray-900 mb-5">Available Balances</h2>
            <div class="space-y-4">
                <div class="flex items-center justify-between p-4 bg-green-50 rounded-xl border border-green-100">
                    <div>
                        <div class="text-green-700 font-medium">Profit Balance</div>
                        <div class="text-green-500 text-xs">Available to withdraw</div>
                    </div>
                    <div class="font-display text-2xl font-bold text-green-700">$<?=number_format($availableProfit,2)?></div>
                </div>
                <div class="flex items-center justify-between p-4 bg-yellow-50 rounded-xl border border-yellow-100">
                    <div>
                        <div style="color:var(--gold-dark)" class="font-medium">Invested Balance</div>
                        <div class="text-yellow-600 text-xs">Principal investment</div>
                    </div>
                    <div class="font-display text-2xl font-bold" style="color:var(--gold-dark)">$<?=number_format($u['invested_balance'],2)?></div>
                </div>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div>
                        <div class="text-gray-700 font-medium">Total Withdrawn</div>
                        <div class="text-gray-400 text-xs">Historical total</div>
                    </div>
                    <div class="font-display text-xl font-bold text-gray-700">$<?=number_format($u['total_withdrawn'],2)?></div>
                </div>
            </div>
            <div class="mt-4 bg-blue-50 rounded-xl p-3 border border-blue-100 text-xs text-blue-700">
                <strong>Note:</strong> Minimum withdrawal: $<?=$minWithdraw?> | Fee: <?=$withdrawFee?>% | Processed in BEP2 USDT
            </div>
        </div>

        <!-- Withdrawal Form -->
        <div class="bg-white rounded-2xl p-6 stat-card">
            <h2 class="font-display font-bold text-gray-900 mb-4">Request Withdrawal</h2>
            <form id="withdrawForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Withdrawal Type</label>
                    <select name="withdrawal_type" id="wd_type" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
                        <option value="profit">From Profit Balance ($<?=number_format($availableProfit,2)?>)</option>
                        <option value="total">From Total Balance (Invest + Profit)</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Amount (USDT)</label>
                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">$</span>
                        <input type="number" name="amount" id="wd_amount" min="<?=$minWithdraw?>" step="0.01" placeholder="<?=$minWithdraw?>.00" class="input-field w-full pl-8 pr-24 py-3 rounded-xl text-gray-900" required>
                        <button type="button" id="wd_max_btn" class="absolute right-3 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded" style="background:var(--gold);color:white">MAX</button>
                    </div>
                    <div id="wd_fee_info" class="text-gray-400 text-xs mt-1"></div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Receiving Wallet (BEP2 USDT)</label>
                    <input type="text" name="wallet_to" value="<?=htmlspecialchars($u['wallet_address']??'')?>" placeholder="Your BEP2 USDT wallet address" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 font-mono text-sm" required>
                </div>
                <?php if($u['kyc_status']==='verified'): ?>
                <button type="submit" id="wdSubmitBtn" class="btn-gold w-full py-4 rounded-xl text-white font-semibold flex items-center justify-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H9m6 0l-3-3m3 3l-3 3"/></svg>
                    Submit Withdrawal Request
                </button>
                <?php else: ?>
                <button disabled class="w-full py-4 rounded-xl font-semibold bg-gray-100 text-gray-400 cursor-not-allowed">Complete KYC First</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Withdrawal History -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Withdrawal History</h2>
        <?php if(count($withdrawals)===0): ?>
        <div class="text-center py-10 text-gray-400">
            <p>No withdrawals yet</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead><tr class="border-b border-gray-100">
                    <th class="text-left py-3 text-gray-400 font-medium">Date</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Amount</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Type</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Wallet</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Status</th>
                </tr></thead>
                <tbody>
                <?php foreach($withdrawals as $wd):
                    $badges = ['pending'=>'badge-yellow','approved'=>'badge-green','rejected'=>'badge-red'];
                ?>
                <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td class="py-3 text-gray-600"><?=date('M j, Y',strtotime($wd['created_at']))?></td>
                    <td class="py-3 font-semibold text-gray-900">$<?=number_format($wd['amount'],2)?></td>
                    <td class="py-3 text-gray-500 capitalize"><?=$wd['withdrawal_type']?></td>
                    <td class="py-3 font-mono text-xs text-gray-500"><?=substr($wd['wallet_to'],0,14).'...'?></td>
                    <td class="py-3"><span class="<?=$badges[$wd['status']]?> px-2 py-1 rounded-full text-xs font-medium"><?=ucfirst($wd['status'])?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const availableProfit = <?=$availableProfit?>;
const totalAvailable = <?=$totalAvailable?>;
const fee = <?=$withdrawFee?>;

$('#wd_type').change(function(){
    const max = $(this).val()==='profit' ? availableProfit : totalAvailable;
    $('#wd_max_btn').data('max', max);
    updateFee();
});

$('#wd_max_btn').click(function(){
    const max = availableProfit;
    const type = $('#wd_type').val();
    $('#wd_amount').val(type==='profit' ? availableProfit.toFixed(2) : totalAvailable.toFixed(2));
    updateFee();
});

$('#wd_amount').on('input', updateFee);

function updateFee(){
    const amt = parseFloat($('#wd_amount').val())||0;
    const feeAmt = amt * fee / 100;
    const netAmt = amt - feeAmt;
    if(amt > 0) {
        $('#wd_fee_info').html(`Fee: $${feeAmt.toFixed(2)} (${fee}%) | You receive: <strong>$${netAmt.toFixed(2)}</strong>`);
    } else {
        $('#wd_fee_info').text('');
    }
}

$('#withdrawForm').submit(function(e){
    e.preventDefault();
    const btn = $('#wdSubmitBtn');
    const amt = parseFloat($('#wd_amount').val());
    const type = $('#wd_type').val();
    const max = type==='profit' ? availableProfit : totalAvailable;
    if(amt > max){ showToast('Amount exceeds available balance','error'); return; }
    btn.html('<svg class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Processing...').prop('disabled',true);
    $.ajax({
        url: '../includes/ajax.php',
        method: 'POST',
        data: $(this).serialize()+'&action=submit_withdrawal',
        dataType: 'json',
        success: function(r){
            if(r.success){
                showToast('Withdrawal requested! Pending admin approval.','success');
                setTimeout(()=>location.reload(),1800);
            } else {
                showToast(r.error||'Error','error');
                btn.html('<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H9m6 0l-3-3m3 3l-3 3"/></svg> Submit Withdrawal Request').prop('disabled',false);
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
