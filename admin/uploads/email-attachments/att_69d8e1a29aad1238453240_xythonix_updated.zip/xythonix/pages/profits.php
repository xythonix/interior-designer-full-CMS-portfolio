<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Profit History';
$u = getCurrentUser();
$db = getDB();

$profitsStmt = $db->prepare("SELECT pd.*, mp.month_year, mp.profit_percent FROM profit_distributions pd JOIN monthly_profits mp ON pd.monthly_profit_id=mp.id WHERE pd.user_id=? ORDER BY mp.month_year DESC");
$profitsStmt->execute([$u['id']]);
$profits = $profitsStmt->fetchAll();

$totalProfit = array_sum(array_column($profits,'profit_amount'));

include '../includes/header.php';
?>

<div class="max-w-4xl mx-auto">
    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-white rounded-2xl p-5 stat-card">
            <div class="text-gray-500 text-xs mb-1">Total Profit Earned</div>
            <div class="font-display text-2xl font-bold text-green-600">$<?=number_format($totalProfit,2)?></div>
        </div>
        <div class="bg-white rounded-2xl p-5 stat-card">
            <div class="text-gray-500 text-xs mb-1">Current Profit Balance</div>
            <div class="font-display text-2xl font-bold" style="color:var(--gold-dark)">$<?=number_format($u['profit_balance'],2)?></div>
        </div>
        <div class="bg-white rounded-2xl p-5 stat-card">
            <div class="text-gray-500 text-xs mb-1">Months Active</div>
            <div class="font-display text-2xl font-bold text-gray-900"><?=count($profits)?></div>
        </div>
    </div>

    <!-- Chart -->
    <?php if(count($profits) > 0): ?>
    <div class="bg-white rounded-2xl p-6 stat-card mb-6">
        <h2 class="font-display font-bold text-gray-900 mb-4">Compound Growth Visualization</h2>
        <canvas id="growthChart" height="120"></canvas>
    </div>
    <?php endif; ?>

    <!-- Profit Table -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Monthly Profit Breakdown</h2>
        <?php if(count($profits)===0): ?>
        <div class="text-center py-10 text-gray-400">
            <svg class="w-12 h-12 mx-auto mb-2 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
            <p class="font-medium">No profits yet</p>
            <p class="text-sm mt-1">Profits are distributed monthly by the admin</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead><tr class="border-b border-gray-100">
                    <th class="text-left py-3 text-gray-400 font-medium">Month</th>
                    <th class="text-right py-3 text-gray-400 font-medium">Balance</th>
                    <th class="text-right py-3 text-gray-400 font-medium">Rate</th>
                    <th class="text-right py-3 text-gray-400 font-medium">Profit</th>
                    <th class="text-right py-3 text-gray-400 font-medium">After Profit</th>
                </tr></thead>
                <tbody>
                <?php $runningBalance = 0; foreach($profits as $p):
                    $afterProfit = $p['balance_snapshot'] + $p['profit_amount'];
                ?>
                <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td class="py-3 font-medium text-gray-900"><?=$p['month_year']?></td>
                    <td class="py-3 text-right text-gray-600">$<?=number_format($p['balance_snapshot'],2)?></td>
                    <td class="py-3 text-right"><span class="badge-gold px-2 py-0.5 rounded-full text-xs"><?=$p['profit_percent']?>%</span></td>
                    <td class="py-3 text-right font-semibold text-green-600">+$<?=number_format($p['profit_amount'],2)?></td>
                    <td class="py-3 text-right font-bold text-gray-900">$<?=number_format($afterProfit,2)?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot><tr class="border-t-2 border-gray-200">
                    <td colspan="3" class="py-3 font-bold text-gray-900">Total Profit</td>
                    <td class="py-3 text-right font-bold text-green-600">+$<?=number_format($totalProfit,2)?></td>
                    <td></td>
                </tr></tfoot>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if(count($profits) > 0): $chartData = array_reverse($profits); ?>
<script>
const ctx = document.getElementById('growthChart').getContext('2d');
const data = <?=json_encode(array_values($chartData))?>;
new Chart(ctx, {
    type: 'line',
    data: {
        labels: data.map(p=>p.month_year),
        datasets: [{
            label: 'Balance After Profit',
            data: data.map(p=>parseFloat(p.balance_snapshot)+parseFloat(p.profit_amount)),
            borderColor: '#C9A84C',
            backgroundColor: 'rgba(201,168,76,0.08)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#C9A84C',
            pointRadius: 5,
        },{
            label: 'Monthly Profit',
            data: data.map(p=>parseFloat(p.profit_amount)),
            borderColor: '#16a34a',
            backgroundColor: 'rgba(22,163,74,0.06)',
            borderWidth: 2,
            fill: false,
            tension: 0.4,
            pointBackgroundColor: '#16a34a',
            pointRadius: 4,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: true } },
        scales: {
            y: { beginAtZero: false, grid: { color: '#f5f5f5' } },
            y1: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } }
        }
    }
});
</script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
