<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'KYC Verification';
$u = getCurrentUser();

include '../includes/header.php';
?>

<div class="max-w-2xl mx-auto">
    <?php if($u['kyc_status']==='verified'): ?>
    <div class="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
        <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h2 class="font-display text-2xl font-bold text-green-800 mb-2">KYC Verified ✓</h2>
        <p class="text-green-600">Your identity has been verified. You can now deposit and withdraw funds.</p>
        <?php if($u['kyc_reviewed_at']): ?>
        <p class="text-green-400 text-sm mt-2">Verified on <?=date('M j, Y',strtotime($u['kyc_reviewed_at']))?></p>
        <?php endif; ?>
    </div>

    <?php elseif($u['kyc_status']==='pending'): ?>
    <div class="bg-yellow-50 border border-yellow-200 rounded-2xl p-8 text-center">
        <div class="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h2 class="font-display text-2xl font-bold text-yellow-800 mb-2">Verification Pending</h2>
        <p class="text-yellow-600">Your documents are under review. This usually takes 24-48 hours.</p>
        <p class="text-yellow-400 text-sm mt-2">Submitted: <?=date('M j, Y',strtotime($u['kyc_submitted_at']))?></p>
    </div>

    <?php elseif($u['kyc_status']==='rejected'): ?>
    <div class="bg-red-50 border border-red-200 rounded-2xl p-5 mb-6">
        <div class="flex gap-3">
            <svg class="w-5 h-5 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <div>
                <div class="font-medium text-red-800">KYC Rejected</div>
                <div class="text-red-600 text-sm mt-1">Reason: <?=htmlspecialchars($u['kyc_rejection_reason']??'Documents unclear or incomplete')?></div>
                <div class="text-red-400 text-xs mt-1">Please resubmit with clear documents below.</div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if(in_array($u['kyc_status'],['none','rejected'])): ?>
    <!-- KYC Form -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-2">Identity Verification</h2>
        <p class="text-gray-500 text-sm mb-6">Upload clear photos of your documents. All documents must be valid and unexpired.</p>

        <form id="kycForm" enctype="multipart/form-data" class="space-y-5">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Document Type</label>
                <select name="doc_type" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
                    <option value="">Select document type</option>
                    <option value="passport">Passport</option>
                    <option value="national_id">National ID Card</option>
                    <option value="drivers_license">Driver's License</option>
                </select>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Document Front</label>
                    <div class="upload-zone border-2 border-dashed border-gray-200 rounded-xl p-4 text-center cursor-pointer hover:border-yellow-400 transition" onclick="$('#doc_front').click()">
                        <div id="front-preview" class="hidden mb-2"><img id="front-img" class="max-h-32 mx-auto rounded-lg"></div>
                        <div id="front-placeholder">
                            <svg class="w-8 h-8 text-gray-300 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                            <p class="text-xs text-gray-400">Click to upload front</p>
                        </div>
                        <input type="file" id="doc_front" name="doc_front" accept="image/*,.pdf" class="hidden" required>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Document Back</label>
                    <div class="upload-zone border-2 border-dashed border-gray-200 rounded-xl p-4 text-center cursor-pointer hover:border-yellow-400 transition" onclick="$('#doc_back').click()">
                        <div id="back-preview" class="hidden mb-2"><img id="back-img" class="max-h-32 mx-auto rounded-lg"></div>
                        <div id="back-placeholder">
                            <svg class="w-8 h-8 text-gray-300 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                            <p class="text-xs text-gray-400">Click to upload back</p>
                        </div>
                        <input type="file" id="doc_back" name="doc_back" accept="image/*,.pdf" class="hidden">
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Selfie with Document</label>
                <div class="upload-zone border-2 border-dashed border-gray-200 rounded-xl p-6 text-center cursor-pointer hover:border-yellow-400 transition" onclick="$('#doc_selfie').click()">
                    <div id="selfie-preview" class="hidden mb-2"><img id="selfie-img" class="max-h-32 mx-auto rounded-lg"></div>
                    <div id="selfie-placeholder">
                        <svg class="w-10 h-10 text-gray-300 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                        <p class="text-sm text-gray-500 font-medium">Upload selfie holding your document</p>
                        <p class="text-xs text-gray-400 mt-1">Your face and document must both be clearly visible</p>
                    </div>
                    <input type="file" id="doc_selfie" name="doc_selfie" accept="image/*" class="hidden" required>
                </div>
            </div>

            <div class="bg-gray-50 rounded-xl p-4 text-xs text-gray-500 space-y-1">
                <div class="font-medium text-gray-700 mb-2">Requirements:</div>
                <div>✓ Documents must be government-issued and valid</div>
                <div>✓ All corners of the document must be visible</div>
                <div>✓ Photos must be clear and not blurry</div>
                <div>✓ Max file size: 5MB per image</div>
            </div>

            <button type="submit" id="kycSubmitBtn" class="btn-gold w-full py-4 rounded-xl text-white font-semibold flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Submit for Verification
            </button>
        </form>
    </div>
    <?php endif; ?>
</div>

<script>
function previewFile(inputId, imgId, previewId, placeholderId){
    $('#'+inputId).change(function(){
        const file = this.files[0];
        if(file && file.type.startsWith('image/')){
            const reader = new FileReader();
            reader.onload = e => {
                $('#'+imgId).attr('src',e.target.result);
                $('#'+previewId).removeClass('hidden');
                $('#'+placeholderId).addClass('hidden');
            };
            reader.readAsDataURL(file);
        }
    });
}
previewFile('doc_front','front-img','front-preview','front-placeholder');
previewFile('doc_back','back-img','back-preview','back-placeholder');
previewFile('doc_selfie','selfie-img','selfie-preview','selfie-placeholder');

$('#kycForm').submit(function(e){
    e.preventDefault();
    const btn = $('#kycSubmitBtn');
    btn.html('<svg class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Uploading...').prop('disabled',true);
    const fd = new FormData(this);
    fd.append('action','submit_kyc');
    $.ajax({
        url: '../includes/ajax.php',
        method: 'POST',
        data: fd,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(r){
            if(r.success){
                showToast('KYC submitted! Under review within 24-48 hours.','success');
                setTimeout(()=>location.reload(),2000);
            } else {
                showToast(r.error||'Upload failed','error');
                btn.html('Submit for Verification').prop('disabled',false);
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
