<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Profile Settings';
$u = getCurrentUser();
$db = getDB();

include '../includes/header.php';
?>

<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-2xl p-6 stat-card mb-6">
        <h2 class="font-display font-bold text-gray-900 mb-5">Profile Information</h2>
        <form id="profileForm" class="space-y-4">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
                    <input type="text" name="name" value="<?=htmlspecialchars($u['name'])?>" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Phone</label>
                    <input type="text" name="phone" value="<?=htmlspecialchars($u['phone']??'')?>" placeholder="+1234567890" class="input-field w-full px-4 py-3 rounded-xl text-gray-900">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <input type="email" value="<?=htmlspecialchars($u['email'])?>" disabled class="w-full px-4 py-3 rounded-xl bg-gray-50 text-gray-400 border-2 border-gray-100">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">BEP2 USDT Wallet Address</label>
                <input type="text" name="wallet_address" value="<?=htmlspecialchars($u['wallet_address']??'')?>" placeholder="Your BEP2 wallet for withdrawals" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 font-mono text-sm">
            </div>
            <button type="submit" class="btn-gold px-6 py-3 rounded-xl text-white font-medium">Save Changes</button>
        </form>
    </div>

    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-5">Change Password</h2>
        <form id="passwordForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Current Password</label>
                <input type="password" name="current_password" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
                    <input type="password" name="new_password" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Confirm New</label>
                    <input type="password" name="confirm_password" class="input-field w-full px-4 py-3 rounded-xl text-gray-900" required>
                </div>
            </div>
            <button type="submit" class="bg-gray-800 text-white px-6 py-3 rounded-xl font-medium hover:bg-gray-700 transition">Change Password</button>
        </form>
    </div>
</div>

<script>
$('#profileForm').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:'../includes/ajax.php',method:'POST',
        data:$(this).serialize()+'&action=update_profile',
        dataType:'json',
        success:r=>r.success?showToast('Profile updated!','success'):showToast(r.error,'error')
    });
});
$('#passwordForm').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:'../includes/ajax.php',method:'POST',
        data:$(this).serialize()+'&action=change_password',
        dataType:'json',
        success:r=>{
            if(r.success){showToast('Password changed!','success');$(this)[0].reset();}
            else showToast(r.error,'error');
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
