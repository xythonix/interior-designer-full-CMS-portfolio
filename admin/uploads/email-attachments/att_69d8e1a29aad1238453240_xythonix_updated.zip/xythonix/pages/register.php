<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = sanitize($_POST['name'] ?? '');
    $email    = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $referral = sanitize($_POST['referral_code'] ?? '');

    if(empty($name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif(strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            $hash    = password_hash($password, PASSWORD_DEFAULT);
            $refCode = generateReferralCode();
            $referredBy = null;
            if($referral) {
                $rs = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
                $rs->execute([$referral]);
                $ref = $rs->fetch();
                if($ref) $referredBy = $ref['id'];
            }

            // Insert user with status pending (unverified)
            $stmt = $db->prepare("INSERT INTO users (name, email, password, referral_code, referred_by, status, email_verified) VALUES (?,?,?,?,?,'pending',0)");
            $stmt->execute([$name, $email, $hash, $refCode, $referredBy]);
            $newId = $db->lastInsertId();

            if($referredBy) {
                $db->prepare("INSERT INTO referrals (referrer_id, referred_id) VALUES (?,?)")->execute([$referredBy, $newId]);
            }

            // Generate verification token
            $token   = generateToken();
            $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));

            // Store token in DB (reuse password_resets table structure)
            $db->prepare("DELETE FROM email_verifications WHERE user_id = ?")->execute([$newId]);
            $db->prepare("INSERT INTO email_verifications (user_id, token, expires_at) VALUES (?,?,?)")->execute([$newId, $token, $expires]);

            // Send verification email
            $verifyLink = SITE_URL . '/pages/verify.php?token=' . $token;
            $emailHtml  = buildVerifyEmailHtml($name, $verifyLink);
            $sent       = sendMail($email, $name, 'Verify Your Xythonix Funds Account', $emailHtml);

            if($sent) {
                $success = 'Registration successful! Please check your email to verify your account.';
            } else {
                // Still registered, but warn about email
                $success = 'Account created! We could not send the verification email — please contact support to verify your account.';
            }
        }
    }
}

function buildVerifyEmailHtml($name, $link) {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f4f4f4;font-family:DM Sans,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:40px 20px;">
<table width="580" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
  <tr><td style="background:linear-gradient(135deg,#0A1628,#142240);padding:40px 40px 30px;text-align:center;">
    <div style="width:48px;height:48px;background:linear-gradient(135deg,#9A7A2E,#C9A84C);border-radius:12px;margin:0 auto 16px;display:inline-flex;align-items:center;justify-content:center;">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
    </div>
    <h1 style="margin:0;font-size:24px;font-weight:700;color:#ffffff;">Xythonix <span style="color:#C9A84C;">Funds</span></h1>
  </td></tr>
  <tr><td style="padding:40px;">
    <h2 style="margin:0 0 12px;font-size:22px;color:#0A1628;">Hi ' . htmlspecialchars($name) . ',</h2>
    <p style="margin:0 0 24px;color:#555;line-height:1.7;">Thank you for registering! Please click the button below to verify your email address and activate your account.</p>
    <div style="text-align:center;margin:32px 0;">
      <a href="' . $link . '" style="display:inline-block;background:linear-gradient(135deg,#9A7A2E,#C9A84C);color:#fff;text-decoration:none;padding:16px 40px;border-radius:12px;font-weight:600;font-size:16px;">Verify My Email</a>
    </div>
    <p style="margin:0 0 8px;color:#888;font-size:13px;">Or copy this link into your browser:</p>
    <p style="margin:0 0 24px;word-break:break-all;font-size:12px;color:#9A7A2E;">' . $link . '</p>
    <p style="margin:0;color:#aaa;font-size:12px;">This link expires in 24 hours. If you did not create an account, you can safely ignore this email.</p>
  </td></tr>
  <tr><td style="background:#f9f9f9;padding:20px 40px;text-align:center;border-top:1px solid #eee;">
    <p style="margin:0;color:#bbb;font-size:12px;">© 2025 Xythonix Funds. All rights reserved.</p>
  </td></tr>
</table></td></tr></table></body></html>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        :root{--gold:#C9A84C;--gold-light:#F0D080;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold),var(--gold-light));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),var(--gold-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{background:linear-gradient(135deg,var(--gold),var(--gold-light));transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
        .input-field{transition:all 0.3s;border:2px solid #e5e7eb;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 4px rgba(201,168,76,0.1);}
        .side-panel{background:linear-gradient(160deg,var(--navy) 0%,#142240 100%);}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex">

<!-- Left Panel -->
<div class="hidden lg:flex lg:w-5/12 side-panel flex-col justify-between p-12">
    <div>
        <a href="../index.php" class="flex items-center gap-3 mb-16">
            <div class="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
            </div>
            <span class="font-display text-xl font-bold text-white">Xythonix <span class="gold-text">Funds</span></span>
        </a>
        <h2 class="font-display text-4xl font-bold text-white leading-tight mb-4">Start Your<br><span class="gold-text">Investment Journey</span></h2>
        <p class="text-white/50 leading-relaxed">Join thousands of investors earning compounding monthly returns on their USDT deposits.</p>
    </div>
    <div class="space-y-4">
        <?php $perks = [['Compound monthly returns','Profits reinvested automatically'],['KYC-secured platform','Identity verified and protected'],['BEP2 USDT deposits','Fast and low-fee transactions']]; foreach($perks as $p): ?>
        <div class="flex items-start gap-3">
            <div class="w-6 h-6 rounded-full gold-gradient flex items-center justify-center flex-shrink-0 mt-0.5">
                <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
            </div>
            <div>
                <div class="text-white font-medium text-sm"><?=$p[0]?></div>
                <div class="text-white/40 text-xs"><?=$p[1]?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Right Panel -->
<div class="flex-1 flex items-center justify-center p-6 lg:p-12">
    <div class="w-full max-w-md">
        <div class="lg:hidden flex items-center gap-2 mb-8">
            <a href="../index.php" class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg gold-gradient flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                </div>
                <span class="font-display font-bold" style="color:var(--navy)">Xythonix Funds</span>
            </a>
        </div>

        <h1 class="font-display text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
        <p class="text-gray-500 mb-8">Already have an account? <a href="login.php" class="font-medium" style="color:var(--gold-dark)">Sign in</a></p>

        <?php if($error): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <?=htmlspecialchars($error)?>
        </div>
        <?php endif; ?>

        <?php if($success): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-4 rounded-xl mb-6">
            <div class="flex items-start gap-3">
                <svg class="w-6 h-6 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <div>
                    <p class="font-semibold mb-1">Account created successfully!</p>
                    <p class="text-sm"><?=htmlspecialchars($success)?></p>
                </div>
            </div>
        </div>
        <?php else: ?>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
                <input type="text" name="name" value="<?=sanitize($_POST['name']??'')?>" placeholder="John Doe" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <input type="email" name="email" value="<?=sanitize($_POST['email']??'')?>" placeholder="john@example.com" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                    <input type="password" name="password" placeholder="Min 8 chars" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Confirm</label>
                    <input type="password" name="confirm_password" placeholder="Repeat" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900" required>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Referral Code <span class="text-gray-400 font-normal">(optional)</span></label>
                <input type="text" name="referral_code" value="<?=sanitize($_GET['ref']??'')?>" placeholder="Enter referral code" class="input-field w-full px-4 py-3 rounded-xl bg-white text-gray-900 uppercase">
            </div>
            <div class="flex items-start gap-2 pt-1">
                <input type="checkbox" id="terms" required class="mt-1 rounded">
                <label for="terms" class="text-sm text-gray-500">I agree to the <a href="#" class="underline" style="color:var(--gold-dark)">Terms of Service</a> and <a href="#" class="underline" style="color:var(--gold-dark)">Privacy Policy</a></label>
            </div>
            <button type="submit" class="btn-gold w-full py-4 rounded-xl text-white font-semibold text-base mt-2">
                Create My Account
            </button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
