<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$token  = trim($_GET['token'] ?? '');
$err    = '';
$msg    = '';
$valid  = false;
$userId = null;

if(empty($token)) {
    $err = 'No reset token provided.';
} else {
    $db   = getDB();
    $stmt = $db->prepare("SELECT pr.*, u.name FROM password_resets pr JOIN users u ON u.id = pr.user_id WHERE pr.token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch();

    if(!$row) {
        $err = 'This reset link is invalid or has already been used.';
    } elseif(strtotime($row['expires_at']) < time()) {
        $err = 'This reset link has expired. Please request a new one.';
    } else {
        $valid  = true;
        $userId = $row['user_id'];
    }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && $valid) {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if(strlen($password) < 8) {
        $err = 'Password must be at least 8 characters.';
    } elseif($password !== $confirm) {
        $err = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $db   = getDB();
        $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $userId]);
        $db->prepare("DELETE FROM password_resets WHERE token = ?")->execute([$token]);

        $valid = false;
        $msg   = 'Your password has been reset successfully. You can now sign in with your new password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        :root{--gold:#C9A84C;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),#F0D080);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .input-field{border:2px solid #e5e7eb;transition:all 0.3s;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 3px rgba(201,168,76,0.1);}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
        .strength-bar{height:4px;border-radius:2px;transition:all 0.3s;}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
<div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-sm border border-gray-100">

    <!-- Logo -->
    <a href="../index.php" class="flex items-center gap-2 mb-8">
        <div class="w-9 h-9 rounded-xl gold-gradient flex items-center justify-center">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
        </div>
        <span class="font-display font-bold text-gray-900">Xythonix <span class="gold-text">Funds</span></span>
    </a>

    <?php if($msg): ?>
    <div class="text-center">
        <div class="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <svg class="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Password Reset!</h1>
        <p class="text-gray-500 mb-8 text-sm"><?=htmlspecialchars($msg)?></p>
        <a href="login.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Sign In Now</a>
    </div>

    <?php elseif(!$valid): ?>
    <div class="text-center">
        <div class="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
            <svg class="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h1 class="font-display text-2xl font-bold text-gray-900 mb-3">Invalid Link</h1>
        <p class="text-gray-500 mb-8 text-sm"><?=htmlspecialchars($err)?></p>
        <a href="forgot_password.php" class="btn-gold inline-block px-8 py-3.5 rounded-xl text-white font-semibold">Request New Link</a>
    </div>

    <?php else: ?>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-2">Set New Password</h1>
    <p class="text-gray-500 text-sm mb-6">Choose a strong password for your account.</p>

    <?php if($err): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2 text-sm">
        <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <?=htmlspecialchars($err)?>
    </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <input type="hidden" name="token" value="<?=htmlspecialchars($token)?>">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
            <input type="password" name="password" id="password" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 bg-white" placeholder="At least 8 characters" required oninput="checkStrength(this.value)">
            <!-- Strength bar -->
            <div class="mt-2 flex gap-1">
                <div id="s1" class="strength-bar flex-1 bg-gray-200"></div>
                <div id="s2" class="strength-bar flex-1 bg-gray-200"></div>
                <div id="s3" class="strength-bar flex-1 bg-gray-200"></div>
                <div id="s4" class="strength-bar flex-1 bg-gray-200"></div>
            </div>
            <p id="strength-label" class="text-xs text-gray-400 mt-1"></p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Confirm New Password</label>
            <input type="password" name="confirm_password" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 bg-white" placeholder="Repeat password" required>
        </div>
        <button type="submit" class="btn-gold w-full py-3.5 rounded-xl text-white font-semibold mt-2">
            Reset Password
        </button>
    </form>
    <?php endif; ?>
</div>

<script>
function checkStrength(val) {
    let score = 0;
    if(val.length >= 8) score++;
    if(/[A-Z]/.test(val)) score++;
    if(/[0-9]/.test(val)) score++;
    if(/[^A-Za-z0-9]/.test(val)) score++;

    const colors = ['','#ef4444','#f97316','#eab308','#22c55e'];
    const labels = ['','Weak','Fair','Good','Strong'];
    for(let i=1;i<=4;i++){
        document.getElementById('s'+i).style.background = i<=score ? colors[score] : '#e5e7eb';
    }
    document.getElementById('strength-label').textContent = val.length ? labels[score] : '';
    document.getElementById('strength-label').style.color = colors[score];
}
</script>
</body>
</html>
