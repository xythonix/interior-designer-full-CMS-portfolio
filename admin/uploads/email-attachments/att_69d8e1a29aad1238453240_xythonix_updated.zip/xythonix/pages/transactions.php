<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Transactions';
$u = getCurrentUser();
$db = getDB();

$txStmt = $db->prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 50");
$txStmt->execute([$u['id']]);
$transactions = $txStmt->fetchAll();

include '../includes/header.php';
?>

<div class="bg-white rounded-2xl p-6 stat-card">
    <div class="flex items-center justify-between mb-6">
        <h2 class="font-display font-bold text-gray-900">All Transactions</h2>
        <div class="flex gap-2" id="filter-btns">
            <button class="filter-btn active text-xs px-3 py-1.5 rounded-lg border border-gray-200" data-filter="all">All</button>
            <button class="filter-btn text-xs px-3 py-1.5 rounded-lg border border-gray-200" data-filter="deposit">Deposits</button>
            <button class="filter-btn text-xs px-3 py-1.5 rounded-lg border border-gray-200" data-filter="profit">Profits</button>
            <button class="filter-btn text-xs px-3 py-1.5 rounded-lg border border-gray-200" data-filter="withdrawal">Withdrawals</button>
        </div>
    </div>
    <?php if(count($transactions)===0): ?>
    <div class="text-center py-16 text-gray-400">
        <svg class="w-14 h-14 mx-auto mb-3 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        <p>No transactions yet</p>
    </div>
    <?php else: ?>
    <div class="space-y-2" id="tx-list">
    <?php
    $icons=['deposit'=>'M12 4v16m8-8H4','withdrawal'=>'M15 12H9m6 0l-3-3m3 3l-3 3','profit'=>'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6','referral_bonus'=>'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z'];
    $bgColors=['deposit'=>'bg-blue-50 text-blue-500','withdrawal'=>'bg-red-50 text-red-500','profit'=>'bg-green-50 text-green-500','referral_bonus'=>'bg-purple-50 text-purple-500'];
    $signs=['deposit'=>'+','withdrawal'=>'-','profit'=>'+','referral_bonus'=>'+'];
    $txCols=['deposit'=>'text-blue-600','withdrawal'=>'text-red-600','profit'=>'text-green-600','referral_bonus'=>'text-purple-600'];
    foreach($transactions as $tx):
    ?>
    <div class="tx-row flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition" data-type="<?=$tx['type']?>">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 <?=$bgColors[$tx['type']]?>">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$icons[$tx['type']]?>"/></svg>
        </div>
        <div class="flex-1">
            <div class="font-medium text-gray-900 text-sm capitalize"><?=str_replace('_',' ',$tx['type'])?></div>
            <div class="text-gray-400 text-xs"><?=$tx['description'] ?? ucfirst($tx['type'].' transaction')?></div>
        </div>
        <div class="text-right">
            <div class="font-semibold <?=$txCols[$tx['type']]?>"><?=$signs[$tx['type']]?>$<?=number_format($tx['amount'],2)?></div>
            <div class="text-gray-400 text-xs"><?=date('M j, Y H:i',strtotime($tx['created_at']))?></div>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
$('.filter-btn').click(function(){
    $('.filter-btn').removeClass('active').css({'background':'','color':'','border-color':''});
    $(this).addClass('active').css({'background':'var(--gold)','color':'white','border-color':'var(--gold)'});
    const f=$(this).data('filter');
    if(f==='all') $('.tx-row').show();
    else $('.tx-row').hide().filter('[data-type="'+f+'"]').show();
});
$('.filter-btn.active').css({'background':'var(--gold)','color':'white','border-color':'var(--gold)'});
</script>

<?php include '../includes/footer.php'; ?>
