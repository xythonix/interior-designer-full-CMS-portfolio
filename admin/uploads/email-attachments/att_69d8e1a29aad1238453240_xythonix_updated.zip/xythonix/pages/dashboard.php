<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Dashboard';
$u = getCurrentUser();
$db = getDB();

// Get stats
$pendingDeposits = $db->prepare("SELECT COALESCE(SUM(amount),0) as total, COUNT(*) as count FROM deposits WHERE user_id=? AND status='pending'");
$pendingDeposits->execute([$u['id']]);
$pendingDep = $pendingDeposits->fetch();

$pendingWithdrawals = $db->prepare("SELECT COALESCE(SUM(amount),0) as total, COUNT(*) as count FROM withdrawals WHERE user_id=? AND status='pending'");
$pendingWithdrawals->execute([$u['id']]);
$pendingWd = $pendingWithdrawals->fetch();

// Monthly profit history for chart
$profitHistory = $db->prepare("SELECT pd.profit_amount, pd.balance_snapshot, mp.month_year, mp.profit_percent FROM profit_distributions pd JOIN monthly_profits mp ON pd.monthly_profit_id=mp.id WHERE pd.user_id=? ORDER BY mp.month_year DESC LIMIT 12");
$profitHistory->execute([$u['id']]);
$profits = $profitHistory->fetchAll();
$profits = array_reverse($profits);

// Recent transactions
$txStmt = $db->prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 10");
$txStmt->execute([$u['id']]);
$transactions = $txStmt->fetchAll();

$monthlyRate = getSetting('monthly_profit_percent');
$systemWallet = getSetting('system_wallet');
$totalBalance = $u['invested_balance'] + $u['profit_balance'] + $u['referral_bonus'];

include '../includes/header.php';
?>

<!-- KYC Alert -->
<?php if($u['kyc_status'] !== 'verified'): ?>
<div class="bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 mb-6 flex items-center justify-between gap-4">
    <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-amber-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        <div>
            <div class="font-medium text-amber-800 text-sm">KYC Verification Required</div>
            <div class="text-amber-600 text-xs">Complete your identity verification to start depositing and investing.</div>
        </div>
    </div>
    <a href="kyc.php" class="bg-amber-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-amber-600 transition flex-shrink-0">Verify Now</a>
</div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <?php
    $stats = [
        ['Total Invested', '$'.number_format($u['invested_balance'],2), 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z', 'var(--gold-dark)', 'bg-yellow-50'],
        ['Profit Balance', '$'.number_format($u['profit_balance'],2), 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z', '#16a34a', 'bg-green-50'],
        ['Total Withdrawn', '$'.number_format($u['total_withdrawn'],2), 'M15 12H9m6 0l-3-3m3 3l-3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z', '#2563eb', 'bg-blue-50'],
        ['Total Balance', '$'.number_format($totalBalance,2), 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6', '#7c3aed', 'bg-purple-50'],
    ];
    foreach($stats as $s):
    ?>
    <div class="stat-card bg-white rounded-2xl p-5">
        <div class="flex items-center justify-between mb-3">
            <div class="w-10 h-10 rounded-xl flex items-center justify-center <?=$s[4]?>">
                <svg class="w-5 h-5" style="color:<?=$s[3]?>" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$s[2]?>"/></svg>
            </div>
        </div>
        <div class="text-xl font-bold text-gray-900"><?=$s[1]?></div>
        <div class="text-gray-500 text-xs mt-1"><?=$s[0]?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Secondary Stats -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <div class="bg-gradient-to-br from-navy to-navy-mid rounded-2xl p-5" style="background:linear-gradient(135deg,var(--navy),#142240)">
        <div class="text-white/50 text-xs mb-1">Current Month Return</div>
        <div class="font-display text-3xl font-bold text-white"><?=$monthlyRate?>%</div>
        <div class="text-white/40 text-xs mt-2">Monthly compound interest</div>
        <?php if($u['invested_balance'] > 0): ?>
        <div class="mt-3 bg-white/10 rounded-lg px-3 py-2">
            <div class="text-yellow-300 text-sm font-medium">Est. this month: +$<?=number_format($u['invested_balance']*$monthlyRate/100,2)?></div>
        </div>
        <?php endif; ?>
    </div>
    <div class="bg-white rounded-2xl p-5 stat-card">
        <div class="text-gray-500 text-xs mb-1">Pending Deposits</div>
        <div class="font-display text-3xl font-bold text-gray-900"><?=$pendingDep['count']?></div>
        <div class="text-gray-400 text-xs mt-1">$<?=number_format($pendingDep['total'],2)?> awaiting verification</div>
        <a href="deposit.php" class="mt-3 inline-block text-xs font-medium" style="color:var(--gold-dark)">+ New Deposit</a>
    </div>
    <div class="bg-white rounded-2xl p-5 stat-card">
        <div class="text-gray-500 text-xs mb-1">Pending Withdrawals</div>
        <div class="font-display text-3xl font-bold text-gray-900"><?=$pendingWd['count']?></div>
        <div class="text-gray-400 text-xs mt-1">$<?=number_format($pendingWd['total'],2)?> awaiting approval</div>
        <a href="withdraw.php" class="mt-3 inline-block text-xs font-medium" style="color:var(--gold-dark)">Request Withdrawal</a>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Profit Chart -->
    <div class="lg:col-span-2 bg-white rounded-2xl p-6 stat-card">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-display font-bold text-gray-900">Monthly Profit History</h2>
            <a href="profits.php" class="text-xs" style="color:var(--gold-dark)">View All →</a>
        </div>
        <?php if(count($profits) > 0): ?>
        <canvas id="profitChart" height="180"></canvas>
        <?php else: ?>
        <div class="flex flex-col items-center justify-center h-40 text-gray-400">
            <svg class="w-12 h-12 mb-2 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
            <p class="text-sm">No profit history yet</p>
            <p class="text-xs mt-1">Profits will appear here after monthly distribution</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- Recent Transactions -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-display font-bold text-gray-900">Recent Activity</h2>
            <a href="transactions.php" class="text-xs" style="color:var(--gold-dark)">All →</a>
        </div>
        <div class="space-y-3">
            <?php if(count($transactions)===0): ?>
            <p class="text-gray-400 text-sm text-center py-6">No transactions yet</p>
            <?php else: foreach($transactions as $tx):
                $icons = ['deposit'=>'M12 4v16m8-8H4','withdrawal'=>'M15 12H9m6 0l-3-3m3 3l-3 3','profit'=>'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6','referral_bonus'=>'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z'];
                $colors = ['deposit'=>'text-blue-500 bg-blue-50','withdrawal'=>'text-red-500 bg-red-50','profit'=>'text-green-500 bg-green-50','referral_bonus'=>'text-purple-500 bg-purple-50'];
                $signs = ['deposit'=>'+','withdrawal'=>'-','profit'=>'+','referral_bonus'=>'+'];
                $txColors = ['deposit'=>'text-blue-600','withdrawal'=>'text-red-600','profit'=>'text-green-600','referral_bonus'=>'text-purple-600'];
            ?>
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 <?=$colors[$tx['type']]?>">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$icons[$tx['type']]?>"/></svg>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium text-gray-900 capitalize"><?=str_replace('_',' ',$tx['type'])?></div>
                    <div class="text-xs text-gray-400"><?=date('M j, Y',strtotime($tx['created_at']))?></div>
                </div>
                <div class="text-sm font-semibold <?=$txColors[$tx['type']]?>"><?=$signs[$tx['type']]?>$<?=number_format($tx['amount'],2)?></div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
    <?php
    $actions = [
        ['Deposit Funds','deposit.php','M12 4v16m8-8H4','btn-gold text-white'],
        ['Withdraw','withdraw.php','M15 12H9m6 0l-3-3m3 3l-3 3','bg-white border-2 border-gray-200 text-gray-700 hover:border-yellow-400'],
        ['KYC Verify','kyc.php','M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0','bg-white border-2 border-gray-200 text-gray-700 hover:border-yellow-400'],
        ['Refer & Earn','referral.php','M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z','bg-white border-2 border-gray-200 text-gray-700 hover:border-yellow-400'],
    ];
    foreach($actions as $a):
    ?>
    <a href="<?=$a[1]?>" class="<?=$a[3]?> rounded-xl px-4 py-3.5 flex items-center gap-3 text-sm font-medium transition-all hover:-translate-y-1">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?=$a[2]?>"/></svg>
        <?=$a[0]?>
    </a>
    <?php endforeach; ?>
</div>

<?php if(count($profits) > 0): ?>
<script>
const profitData = <?=json_encode(array_values($profits))?>;
const ctx = document.getElementById('profitChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: profitData.map(p => p.month_year),
        datasets: [{
            label: 'Monthly Profit ($)',
            data: profitData.map(p => parseFloat(p.profit_amount)),
            backgroundColor: 'rgba(201,168,76,0.2)',
            borderColor: '#C9A84C',
            borderWidth: 2,
            borderRadius: 6,
        },{
            label: 'Balance Snapshot ($)',
            data: profitData.map(p => parseFloat(p.balance_snapshot)),
            type: 'line',
            borderColor: '#16a34a',
            backgroundColor: 'rgba(22,163,74,0.05)',
            borderWidth: 2,
            pointRadius: 4,
            fill: true,
            tension: 0.4,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: true, position: 'top' } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f5f5f5' } },
            y1: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } }
        }
    }
});
</script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
