<?php
require_once '../includes/config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$msg = '';
$err = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');

    if(empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Please enter a valid email address.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT id, name FROM users WHERE email = ? AND status != 'suspended'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if($user) {
            // Generate reset token
            $token   = generateToken();
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Delete any existing tokens for this user
            $db->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$user['id']]);
            $db->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)")->execute([$user['id'], $token, $expires]);

            // Build reset link
            $resetLink = SITE_URL . '/pages/reset_password.php?token=' . $token;
            $htmlBody  = buildResetEmailHtml($user['name'], $resetLink);

            $sent = sendMail($email, $user['name'], 'Reset Your Xythonix Funds Password', $htmlBody);

            if($sent) {
                $msg = 'A password reset link has been sent to your email. Please check your inbox (and spam folder).';
            } else {
                $err = 'We encountered an error sending the email. Please try again or contact support.';
            }
        } else {
            // Don't reveal if email exists
            $msg = 'If that email is registered, a reset link has been sent.';
        }
    }
}

function buildResetEmailHtml($name, $link) {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:40px 20px;">
<table width="580" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
  <tr><td style="background:linear-gradient(135deg,#0A1628,#142240);padding:40px;text-align:center;">
    <h1 style="margin:0;font-size:24px;font-weight:700;color:#fff;">Xythonix <span style="color:#C9A84C;">Funds</span></h1>
  </td></tr>
  <tr><td style="padding:40px;">
    <h2 style="margin:0 0 12px;font-size:20px;color:#0A1628;">Password Reset Request</h2>
    <p style="margin:0 0 8px;color:#555;line-height:1.7;">Hi ' . htmlspecialchars($name) . ',</p>
    <p style="margin:0 0 24px;color:#555;line-height:1.7;">We received a request to reset your password. Click the button below to set a new password. This link is valid for <strong>1 hour</strong>.</p>
    <div style="text-align:center;margin:32px 0;">
      <a href="' . $link . '" style="display:inline-block;background:linear-gradient(135deg,#9A7A2E,#C9A84C);color:#fff;text-decoration:none;padding:16px 40px;border-radius:12px;font-weight:600;font-size:16px;">Reset My Password</a>
    </div>
    <p style="margin:0 0 8px;color:#888;font-size:13px;">Or copy this link:</p>
    <p style="margin:0 0 24px;word-break:break-all;font-size:12px;color:#9A7A2E;">' . $link . '</p>
    <p style="margin:0;color:#aaa;font-size:12px;">If you did not request a password reset, please ignore this email. Your password will not change.</p>
  </td></tr>
  <tr><td style="background:#f9f9f9;padding:20px 40px;text-align:center;border-top:1px solid #eee;">
    <p style="margin:0;color:#bbb;font-size:12px;">© 2025 Xythonix Funds. All rights reserved.</p>
  </td></tr>
</table></td></tr></table></body></html>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password – Xythonix Funds</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'DM Sans', sans-serif; }
        .font-display { font-family: 'Playfair Display', serif; }
        :root{--gold:#C9A84C;--gold-dark:#9A7A2E;--navy:#0A1628;}
        .gold-gradient{background:linear-gradient(135deg,var(--gold-dark),var(--gold));}
        .gold-text{background:linear-gradient(135deg,var(--gold-dark),#F0D080);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .input-field{border:2px solid #e5e7eb;transition:all 0.3s;}
        .input-field:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 3px rgba(201,168,76,0.1);}
        .btn-gold{background:linear-gradient(135deg,var(--gold-dark),var(--gold));transition:all 0.3s;}
        .btn-gold:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(201,168,76,0.4);}
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
<div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-sm border border-gray-100">

    <!-- Logo -->
    <a href="../index.php" class="flex items-center gap-2 mb-6">
        <div class="w-9 h-9 rounded-xl gold-gradient flex items-center justify-center">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
        </div>
        <span class="font-display font-bold text-gray-900">Xythonix <span class="gold-text">Funds</span></span>
    </a>

    <a href="login.php" class="flex items-center gap-1.5 text-gray-400 hover:text-gray-600 text-sm mb-6 transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        Back to login
    </a>

    <h1 class="font-display text-2xl font-bold text-gray-900 mb-2">Forgot Password?</h1>
    <p class="text-gray-500 text-sm mb-6">Enter your registered email and we'll send you a secure reset link.</p>

    <?php if($msg): ?>
    <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-6 flex items-start gap-2">
        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span class="text-sm"><?=htmlspecialchars($msg)?></span>
    </div>
    <?php endif; ?>

    <?php if($err): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span class="text-sm"><?=htmlspecialchars($err)?></span>
    </div>
    <?php endif; ?>

    <?php if(!$msg): ?>
    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
            <input type="email" name="email" value="<?=sanitize($_POST['email']??'')?>" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 bg-white" placeholder="you@example.com" required>
        </div>
        <button type="submit" class="btn-gold w-full py-3.5 rounded-xl text-white font-semibold">
            Send Reset Link
        </button>
    </form>
    <?php else: ?>
    <a href="login.php" class="btn-gold block text-center py-3.5 rounded-xl text-white font-semibold">Back to Sign In</a>
    <?php endif; ?>
</div>
</body>
</html>
