<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Referral Program';
$u = getCurrentUser();
$db = getDB();

$refStmt = $db->prepare("SELECT r.*, u.name, u.email, u.created_at as joined, u.kyc_status, u.invested_balance FROM referrals r JOIN users u ON r.referred_id=u.id WHERE r.referrer_id=?");
$refStmt->execute([$u['id']]);
$referrals = $refStmt->fetchAll();
$referralLink = SITE_URL.'/pages/register.php?ref='.$u['referral_code'];
$bonusRate = getSetting('referral_bonus_percent');

include '../includes/header.php';
?>

<div class="max-w-3xl mx-auto">
    <!-- Referral Card -->
    <div class="rounded-2xl p-8 mb-6 text-white" style="background:linear-gradient(135deg,var(--navy),#142240)">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h2 class="font-display text-2xl font-bold mb-1">Refer & Earn</h2>
                <p class="text-white/60 text-sm">Earn <?=$bonusRate?>% bonus on your referrals' first investment</p>
            </div>
            <div class="text-center">
                <div class="font-display text-3xl font-bold gold-text"><?=count($referrals)?></div>
                <div class="text-white/40 text-xs">Referrals</div>
            </div>
        </div>
        <div class="bg-white/10 rounded-xl p-4 mb-4">
            <div class="text-white/50 text-xs mb-2">Your Referral Code</div>
            <div class="flex items-center gap-3">
                <span class="font-mono text-yellow-300 font-bold text-xl tracking-widest"><?=$u['referral_code']?></span>
            </div>
        </div>
        <div class="bg-white/10 rounded-xl p-4">
            <div class="text-white/50 text-xs mb-2">Referral Link</div>
            <div class="flex items-center gap-3">
                <span id="ref-link" class="text-white/80 text-sm font-mono truncate flex-1"><?=$referralLink?></span>
                <button onclick="copyRef()" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg" style="background:var(--gold);color:white">Copy</button>
            </div>
        </div>
        <div class="mt-4">
            <div class="text-white/40 text-xs mb-1">Referral Bonus Balance</div>
            <div class="font-display text-2xl font-bold text-green-400">$<?=number_format($u['referral_bonus'],2)?></div>
        </div>
    </div>

    <!-- Referrals List -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Your Referrals (<?=count($referrals)?>)</h2>
        <?php if(count($referrals)===0): ?>
        <div class="text-center py-10 text-gray-400">
            <svg class="w-12 h-12 mx-auto mb-2 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            <p>No referrals yet. Share your link to start earning!</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead><tr class="border-b border-gray-100">
                    <th class="text-left py-3 text-gray-400 font-medium">User</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Joined</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Invested</th>
                    <th class="text-left py-3 text-gray-400 font-medium">KYC</th>
                    <th class="text-right py-3 text-gray-400 font-medium">Bonus</th>
                </tr></thead>
                <tbody>
                <?php foreach($referrals as $r): ?>
                <tr class="border-b border-gray-50">
                    <td class="py-3">
                        <div class="font-medium text-gray-900"><?=htmlspecialchars($r['name'])?></div>
                        <div class="text-gray-400 text-xs"><?=htmlspecialchars($r['email'])?></div>
                    </td>
                    <td class="py-3 text-gray-500"><?=date('M j, Y',strtotime($r['joined']))?></td>
                    <td class="py-3 font-semibold text-gray-900">$<?=number_format($r['invested_balance'],2)?></td>
                    <td class="py-3"><?php if($r['kyc_status']==='verified'): ?><span class="badge-green px-2 py-0.5 rounded-full text-xs">Verified</span><?php else: ?><span class="badge-yellow px-2 py-0.5 rounded-full text-xs">Pending</span><?php endif; ?></td>
                    <td class="py-3 text-right font-semibold text-green-600">$<?=number_format($r['bonus_amount'],2)?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function copyRef(){
    navigator.clipboard.writeText('<?=$referralLink?>');
    showToast('Referral link copied!','success');
}
</script>

<?php include '../includes/footer.php'; ?>
