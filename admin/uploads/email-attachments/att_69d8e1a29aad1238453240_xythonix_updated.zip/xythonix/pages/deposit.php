<?php
require_once '../includes/config.php';
requireLogin();
$pageTitle = 'Deposit Funds';
$u = getCurrentUser();
$db = getDB();
$systemWallet = getSetting('system_wallet');
$minDeposit = getSetting('min_deposit');

// Get deposit history
$depStmt = $db->prepare("SELECT * FROM deposits WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
$depStmt->execute([$u['id']]);
$deposits = $depStmt->fetchAll();

include '../includes/header.php';
?>

<div class="max-w-4xl mx-auto">
    <!-- KYC Check -->
    <?php if($u['kyc_status'] !== 'verified'): ?>
    <div class="bg-amber-50 border border-amber-200 rounded-2xl p-6 mb-6 text-center">
        <svg class="w-12 h-12 text-amber-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        <h3 class="font-display font-bold text-amber-800 text-lg mb-2">KYC Verification Required</h3>
        <p class="text-amber-700 text-sm mb-4">You must complete identity verification before making deposits.</p>
        <a href="kyc.php" class="btn-gold inline-block px-6 py-3 rounded-xl text-white font-medium">Complete KYC →</a>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Deposit Instructions -->
        <div class="bg-white rounded-2xl p-6 stat-card">
            <h2 class="font-display font-bold text-gray-900 mb-4">System Wallet Address</h2>
            <div class="bg-gray-50 rounded-xl p-4 border-2 border-dashed border-gray-200 mb-4 text-center">
                <div class="text-xs text-gray-400 mb-2">BEP2 USDT Deposit Address</div>
                <div id="wallet-addr" class="font-mono text-sm text-gray-800 break-all font-medium"><?=htmlspecialchars($systemWallet)?></div>
                <button onclick="copyWallet()" class="mt-3 flex items-center gap-2 mx-auto text-xs px-3 py-1.5 rounded-lg border border-gray-200 hover:border-yellow-400 transition text-gray-600">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    Copy Address
                </button>
            </div>
            <div class="space-y-2">
                <?php $steps = ['Send BEP2 USDT to the wallet address above','Copy the transaction hash after sending','Fill in the form and submit your deposit request','Admin will verify your deposit within 24 hours']; foreach($steps as $i=>$s): ?>
                <div class="flex items-start gap-3">
                    <div class="w-6 h-6 rounded-full gold-gradient text-white text-xs flex items-center justify-center flex-shrink-0 font-bold"><?=$i+1?></div>
                    <p class="text-gray-600 text-sm"><?=$s?></p>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="mt-4 bg-blue-50 rounded-xl p-3 border border-blue-100">
                <div class="text-blue-700 text-xs font-medium">⚠️ Important: Minimum deposit is $<?=$minDeposit?> USDT. Only BEP2 (Binance Smart Chain) USDT accepted.</div>
            </div>
        </div>

        <!-- Deposit Form -->
        <div class="bg-white rounded-2xl p-6 stat-card">
            <h2 class="font-display font-bold text-gray-900 mb-4">Submit Deposit</h2>
            <form id="depositForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Amount (USDT)</label>
                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">$</span>
                        <input type="number" name="amount" id="dep_amount" min="<?=$minDeposit?>" step="0.01" placeholder="<?=$minDeposit?>.00" class="input-field w-full pl-8 pr-4 py-3 rounded-xl text-gray-900" required>
                    </div>
                    <p class="text-gray-400 text-xs mt-1">Minimum: $<?=$minDeposit?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Transaction Hash (TxID)</label>
                    <input type="text" name="txn_hash" placeholder="0x..." class="input-field w-full px-4 py-3 rounded-xl text-gray-900 font-mono text-sm" required>
                    <p class="text-gray-400 text-xs mt-1">The transaction hash from your wallet/exchange</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Your Sending Wallet (optional)</label>
                    <input type="text" name="wallet_from" placeholder="Your BEP2 wallet address" class="input-field w-full px-4 py-3 rounded-xl text-gray-900 font-mono text-sm">
                </div>
                <?php if($u['kyc_status']==='verified'): ?>
                <button type="submit" id="depSubmitBtn" class="btn-gold w-full py-4 rounded-xl text-white font-semibold flex items-center justify-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    Submit Deposit Request
                </button>
                <?php else: ?>
                <button disabled class="w-full py-4 rounded-xl font-semibold bg-gray-100 text-gray-400 cursor-not-allowed">
                    Complete KYC First
                </button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Deposit History -->
    <div class="bg-white rounded-2xl p-6 stat-card">
        <h2 class="font-display font-bold text-gray-900 mb-4">Deposit History</h2>
        <?php if(count($deposits)===0): ?>
        <div class="text-center py-10 text-gray-400">
            <svg class="w-12 h-12 mx-auto mb-2 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M12 4v16m8-8H4"/></svg>
            <p>No deposits yet</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead><tr class="border-b border-gray-100">
                    <th class="text-left py-3 text-gray-400 font-medium">Date</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Amount</th>
                    <th class="text-left py-3 text-gray-400 font-medium">TxHash</th>
                    <th class="text-left py-3 text-gray-400 font-medium">Status</th>
                </tr></thead>
                <tbody>
                <?php foreach($deposits as $d):
                    $badges = ['pending'=>'badge-yellow','verified'=>'badge-green','rejected'=>'badge-red'];
                ?>
                <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td class="py-3 text-gray-600"><?=date('M j, Y',strtotime($d['created_at']))?></td>
                    <td class="py-3 font-semibold text-gray-900">$<?=number_format($d['amount'],2)?></td>
                    <td class="py-3 font-mono text-xs text-gray-500"><?=$d['txn_hash'] ? substr($d['txn_hash'],0,16).'...' : '—'?></td>
                    <td class="py-3"><span class="<?=$badges[$d['status']]?> px-2 py-1 rounded-full text-xs font-medium"><?=ucfirst($d['status'])?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function copyWallet(){
    navigator.clipboard.writeText(document.getElementById('wallet-addr').textContent.trim());
    showToast('Wallet address copied!','success');
}

$('#depositForm').submit(function(e){
    e.preventDefault();
    const btn = $('#depSubmitBtn');
    btn.html('<svg class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Submitting...').prop('disabled',true);
    $.ajax({
        url: '../includes/ajax.php',
        method: 'POST',
        data: $(this).serialize()+'&action=submit_deposit',
        dataType: 'json',
        success: function(r){
            if(r.success){
                showToast('Deposit submitted! Pending admin verification.','success');
                setTimeout(()=>location.reload(),1800);
            } else {
                showToast(r.error||'Error submitting deposit','error');
                btn.html('<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> Submit Deposit Request').prop('disabled',false);
            }
        },
        error: ()=>{ showToast('Server error','error'); btn.prop('disabled',false); }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
