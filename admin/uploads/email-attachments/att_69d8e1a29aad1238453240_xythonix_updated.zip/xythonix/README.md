# Xythonix Funds – Investment Platform
## Complete Setup Guide

---

## 📁 Directory Structure
```
xythonix/
├── index.php                  ← Landing page
├── database.sql               ← Database schema + seed data
├── includes/
│   ├── config.php             ← DB config, helper functions
│   ├── header.php             ← User sidebar/header
│   ├── footer.php             ← User footer + JS
│   └── ajax.php               ← User AJAX handler
├── pages/
│   ├── login.php
│   ├── register.php
│   ├── dashboard.php          ← User dashboard with charts
│   ├── deposit.php
│   ├── withdraw.php
│   ├── profits.php            ← Profit history + charts
│   ├── transactions.php
│   ├── kyc.php                ← KYC document upload
│   ├── referral.php
│   ├── profile.php
│   ├── google_auth.php        ← Google OAuth (setup required)
│   ├── forgot_password.php
│   └── logout.php
├── admin/
│   ├── dashboard.php          ← Admin overview
│   ├── deposits.php           ← Verify/reject deposits
│   ├── withdrawals.php        ← Approve/reject withdrawals
│   ├── profits.php            ← Set rate + distribute profit
│   ├── users.php              ← User management
│   ├── kyc.php                ← KYC document review
│   ├── settings.php           ← System settings
│   ├── admin_ajax.php         ← Admin AJAX + profit engine
│   ├── header.php
│   └── footer.php
└── uploads/
    └── kyc/                   ← KYC document storage
```

---

## 🚀 Installation Steps

### 1. Web Server Setup
- Place the `xythonix` folder in your web root (e.g., `/var/www/html/` or `htdocs/`)
- Ensure PHP 7.4+ with PDO MySQL extension
- Set `uploads/kyc/` directory permissions: `chmod 755 uploads/ uploads/kyc/`

### 2. Database Setup
```sql
-- Run in MySQL:
source /path/to/xythonix/database.sql;
```
Or import `database.sql` via phpMyAdmin.

### 3. Configure Database Connection
Edit `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_NAME', 'xythonix_funds');
define('SITE_URL', 'http://yourdomain.com/xythonix');
```

### 4. Admin Login
- URL: `http://yourdomain.com/xythonix/pages/login.php`
- Email: `admin@xythonixfunds.com`
- Password: `password`
- **⚠️ Change this password immediately after first login!**

---

## 💰 How Compounding Profit Works

The profit engine in `admin/admin_ajax.php` (case: `distribute_profit`):

```
Current Balance = invested_balance + existing profit_balance
Profit Amount   = Current Balance × (profit_rate / 100)
```

**Example:**
- Month 1: Deposit $1,000 → invested_balance = $1,000
- Admin sets 3% rate → distributes profit
- Profit = $1,000 × 3% = $30 → profit_balance = $30
- Month 2: Current balance = $1,000 + $30 = $1,030
- Profit = $1,030 × 3% = $30.90 → profit_balance = $60.90
- Month 3: Current balance = $1,030 + $30.90 = $1,060.90
- Profit = $1,060.90 × 3% = $31.83 → and so on...

---

## 🔑 Key Features

| Feature | Location |
|---------|----------|
| User registration/login | `pages/register.php`, `pages/login.php` |
| KYC document upload | `pages/kyc.php` → `includes/ajax.php` |
| Deposit (BEP2 USDT) | `pages/deposit.php` → `includes/ajax.php` |
| Monthly compound profit | `admin/profits.php` → `admin/admin_ajax.php` |
| Withdrawal requests | `pages/withdraw.php` → `includes/ajax.php` |
| Admin deposit verify | `admin/deposits.php` → `admin/admin_ajax.php` |
| Admin withdrawal approve | `admin/withdrawals.php` → `admin/admin_ajax.php` |
| Referral system | `pages/referral.php` |
| Profit charts (Chart.js) | `pages/dashboard.php`, `pages/profits.php` |
| System settings | `admin/settings.php` |

---

## 📊 Monthly Profit Distribution Flow

1. Admin goes to `admin/profits.php`
2. Views preview of all eligible users and estimated total distribution
3. Sets profit rate (if changing)
4. Clicks **"Distribute Profit"** button
5. System calculates compound profit for EACH user
6. Profit added to each user's `profit_balance`
7. Transaction logged for every user
8. Cannot be applied twice for same month

---

## 🔐 Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create/select a project
3. Enable Google OAuth2 API
4. Create OAuth credentials
5. Add redirect URI: `http://yourdomain.com/xythonix/pages/google_callback.php`
6. Update `includes/config.php`:
   ```php
   define('GOOGLE_CLIENT_ID', 'xwdukttlyhnjavkq');
   define('GOOGLE_CLIENT_SECRET', 'your_client_secret_here');
   ```

---

## 🛡️ Security Notes

- All inputs are sanitized via `sanitize()` function
- PDO prepared statements used throughout (SQL injection safe)
- Session-based authentication
- Admin routes protected with `requireAdmin()`
- KYC files stored outside web root recommended in production
- Add CSRF tokens for production deployment
- Use HTTPS in production

---

## 📱 Tech Stack

- **Backend:** PHP 8.x with PDO MySQL
- **Frontend:** Tailwind CSS (CDN), Chart.js, jQuery + AJAX
- **Database:** MySQL 8.x
- **Fonts:** Playfair Display + DM Sans (Google Fonts)
- **Icons:** Heroicons (inline SVG)
- **Auth:** Session-based + Google OAuth2 (optional)
